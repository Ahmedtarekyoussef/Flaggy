import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class sixSix extends JPanel {
	
JButton sixSixCont;	
JButton sixSixRestart;

public sixSix() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.sixSixCont= new JButton();
	this.sixSixCont.setLayout(null);
	this.sixSixCont.setBounds(900, 550, 300, 50);
	this.sixSixCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.sixSixCont.setForeground(Color.decode("#540a04"));
	this.sixSixCont.setBackground(Color.decode("#d3842e"));
	this.sixSixCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.sixSixCont.setText("Go To Flag 7");
	this.add(sixSixCont);
	
	this.sixSixRestart= new JButton();
	this.sixSixRestart.setLayout(null);
	this.sixSixRestart.setBounds(1200, 5, 160, 40);
	this.sixSixRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.sixSixRestart.setForeground(Color.decode("#162550"));
	this.sixSixRestart.setBackground(Color.decode("#d3842e"));
	this.sixSixRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.sixSixRestart.setText("Restart Game");
	this.add(sixSixRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
}
	
}
