import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class sevenSeven extends JPanel {
	
JButton sevenSevenCont;	
JButton sevenSevenRestart;

public sevenSeven() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.sevenSevenCont= new JButton();
	this.sevenSevenCont.setLayout(null);
	this.sevenSevenCont.setBounds(900, 550, 300, 50);
	this.sevenSevenCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.sevenSevenCont.setForeground(Color.decode("#540a04"));
	this.sevenSevenCont.setBackground(Color.decode("#d3842e"));
	this.sevenSevenCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.sevenSevenCont.setText("Go To Flag 8");
	this.add(sevenSevenCont);
	
	this.sevenSevenRestart= new JButton();
	this.sevenSevenRestart.setLayout(null);
	this.sevenSevenRestart.setBounds(1200, 5, 160, 40);
	this.sevenSevenRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.sevenSevenRestart.setForeground(Color.decode("#162550"));
	this.sevenSevenRestart.setBackground(Color.decode("#d3842e"));
	this.sevenSevenRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.sevenSevenRestart.setText("Restart Game");
	this.add(sevenSevenRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
}
	
}
