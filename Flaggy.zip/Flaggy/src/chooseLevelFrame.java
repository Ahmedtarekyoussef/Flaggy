import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class chooseLevelFrame extends JPanel {
	
	JLabel nameLevel;
	JButton chooseLevelFrameBack;
	JTextField userName;
	JButton levelOne;
	JButton levelTwo;
	JButton levelThree;
	JButton levelFour;
	
	public chooseLevelFrame () {
	
		this.setLayout(null);
		this.setPreferredSize(new Dimension(1920,1080));
		this.setBackground(Color.decode("#e6c580"));
		
		this.nameLevel = new JLabel();
		nameLevel.setText("Please enter your name and choose the level");
		nameLevel.setBounds(615, -35, 700, 600);
		nameLevel.setLayout(null);
		nameLevel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		nameLevel.setForeground(Color.decode("#5f2e1e"));
		this.add(nameLevel);
		
		this.chooseLevelFrameBack= new JButton();
 		this.chooseLevelFrameBack.setLayout(null);
		this.chooseLevelFrameBack.setBounds(10, 550, 100, 50);
		this.chooseLevelFrameBack.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
		this.chooseLevelFrameBack.setForeground(Color.decode("#540a04"));
		this.chooseLevelFrameBack.setBackground(Color.decode("#d3842e"));
		this.chooseLevelFrameBack.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		this.chooseLevelFrameBack.setText("Back");
		this.add(chooseLevelFrameBack);
		
		this.userName = new JTextField("");
		this.userName.setBounds(900,300, 200, 40);
		this.userName.setBorder(BorderFactory.createLineBorder(Color.decode("#5c6b96"), 5));
		this.userName.setBackground(Color.decode("#5c6b96"));
		this.add(userName);
		
		this.levelOne= new JButton();
		this.levelOne.setLayout(null);
		this.levelOne.setBounds(375, 400, 400, 50);
		this.levelOne.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		this.levelOne.setForeground(Color.decode("#162550"));
		this.levelOne.setBackground(Color.decode("#d3842e"));
		this.levelOne.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		this.levelOne.setText("Easy");
		this.add(levelOne);
		
		this.levelTwo= new JButton();
		this.levelTwo.setLayout(null);
		this.levelTwo.setBounds(900, 400, 300, 50);
		this.levelTwo.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		this.levelTwo.setForeground(Color.decode("#162550"));
		this.levelTwo.setBackground(Color.decode("#d3842e"));
		this.levelTwo.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		this.levelTwo.setText("Medium");
		this.add(levelTwo);
		
		this.levelThree= new JButton();
		this.levelThree.setLayout(null);
		this.levelThree.setBounds(375, 550, 300, 50);
		this.levelThree.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		this.levelThree.setForeground(Color.decode("#162550"));
		this.levelThree.setBackground(Color.decode("#d3842e"));
		this.levelThree.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		this.levelThree.setText("Hard");
		this.add(levelThree);
		
		this.levelFour= new JButton();
		this.levelFour.setLayout(null);
		this.levelFour.setBounds(900, 550, 300, 50);
		this.levelFour.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		this.levelFour.setForeground(Color.decode("#162550"));
		this.levelFour.setBackground(Color.decode("#d3842e"));
		this.levelFour.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		this.levelFour.setText("Very Hard");
		this.add(levelFour);
		
		
	}
	
}
