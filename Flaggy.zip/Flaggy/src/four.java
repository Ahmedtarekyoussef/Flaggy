import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class four extends JPanel {
	
	JButton fourRestart;
	JButton fourC1;
	JButton fourC2;
	JButton fourC3;
	JButton fourC4;
	JLabel fourL;
	
	public four() {
	
		this.setLayout(null);
		this.setPreferredSize(new Dimension(1920,1080));
		this.setBackground(Color.decode("#e6c580"));
		
		fourC1= new JButton();
		fourC1.setLayout(null);
		fourC1.setBounds(375, 400, 400, 50);
		fourC1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		fourC1.setForeground(Color.decode("#162550"));
		fourC1.setBackground(Color.decode("#d3842e"));
		fourC1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		fourC1.setText("");
		this.add(fourC1);
		
		fourC2= new JButton();
		fourC2.setLayout(null);
		fourC2.setBounds(900, 400, 300, 50);
		fourC2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		fourC2.setForeground(Color.decode("#162550"));
		fourC2.setBackground(Color.decode("#d3842e"));
		fourC2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		fourC2.setText("");
		this.add(fourC2);
		
		fourC3= new JButton();
		fourC3.setLayout(null);
		fourC3.setBounds(375, 550, 300, 50);
		fourC3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		fourC3.setForeground(Color.decode("#162550"));
		fourC3.setBackground(Color.decode("#d3842e"));
		fourC3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		fourC3.setText("");
		this.add(fourC3);
		
		fourC4= new JButton();
		fourC4.setLayout(null);
		fourC4.setBounds(900, 550, 300, 50);
		fourC4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		fourC4.setForeground(Color.decode("#162550"));
		fourC4.setBackground(Color.decode("#d3842e"));
		fourC4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		fourC4.setText("");
		this.add(fourC4);
		
		this.fourRestart= new JButton();
		this.fourRestart.setLayout(null);
		this.fourRestart.setBounds(1200, 5, 160, 40);
		this.fourRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		this.fourRestart.setForeground(Color.decode("#162550"));
		this.fourRestart.setBackground(Color.decode("#d3842e"));
		this.fourRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		this.fourRestart.setText("Restart Game");
		this.add(fourRestart);
		
		JLabel fourL = new JLabel();
		fourL.setText("Flag 4" );
		fourL.setBounds(1200, 50, 160, 40);
		fourL.setLayout(null);
		fourL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		fourL.setForeground(Color.decode("#5f2e1e"));
		this.add(fourL);
		
	}

}