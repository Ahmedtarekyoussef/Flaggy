import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class nineNine extends JPanel {
	
JButton nineNineCont;	
JButton nineNineRestart;

public nineNine() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.nineNineCont= new JButton();
	this.nineNineCont.setLayout(null);
	this.nineNineCont.setBounds(900, 550, 300, 50);
	this.nineNineCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.nineNineCont.setForeground(Color.decode("#540a04"));
	this.nineNineCont.setBackground(Color.decode("#d3842e"));
	this.nineNineCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.nineNineCont.setText("Go To Flag 10");
	this.add(nineNineCont);
	
	this.nineNineRestart= new JButton();
	this.nineNineRestart.setLayout(null);
	this.nineNineRestart.setBounds(1200, 5, 160, 40);
	this.nineNineRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.nineNineRestart.setForeground(Color.decode("#162550"));
	this.nineNineRestart.setBackground(Color.decode("#d3842e"));
	this.nineNineRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.nineNineRestart.setText("Restart Game");
	this.add(nineNineRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
}
	
}
