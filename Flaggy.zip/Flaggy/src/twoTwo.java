import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class twoTwo extends JPanel {
	
JButton twoTwoCont;	
JButton twoTwoRestart;

public twoTwo() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.twoTwoCont= new JButton();
	this.twoTwoCont.setLayout(null);
	this.twoTwoCont.setBounds(900, 550, 300, 50);
	this.twoTwoCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.twoTwoCont.setForeground(Color.decode("#540a04"));
	this.twoTwoCont.setBackground(Color.decode("#d3842e"));
	this.twoTwoCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.twoTwoCont.setText("Go To Flag 3");
	this.add(twoTwoCont);
	
	this.twoTwoRestart= new JButton();
	this.twoTwoRestart.setLayout(null);
	this.twoTwoRestart.setBounds(1200, 5, 160, 40);
	this.twoTwoRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.twoTwoRestart.setForeground(Color.decode("#162550"));
	this.twoTwoRestart.setBackground(Color.decode("#d3842e"));
	this.twoTwoRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.twoTwoRestart.setText("Restart Game");
	this.add(twoTwoRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
}
	
}
