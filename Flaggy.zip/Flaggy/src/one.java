import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class one extends JPanel {
	
	JButton restart;
	JButton c1;
	JButton c2;
	JButton c3;
	JButton c4;
	JLabel oneL;
	
	public one() {
	
		this.setLayout(null);
		this.setPreferredSize(new Dimension(1920,1080));
		this.setBackground(Color.decode("#e6c580"));
		
		c1= new JButton();
		c1.setLayout(null);
		c1.setBounds(375, 400, 400, 50);
		c1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		c1.setForeground(Color.decode("#162550"));
		c1.setBackground(Color.decode("#d3842e"));
		c1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		c1.setText("");
		this.add(c1);
		
		c2= new JButton();
		c2.setLayout(null);
		c2.setBounds(900, 400, 300, 50);
		c2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		c2.setForeground(Color.decode("#162550"));
		c2.setBackground(Color.decode("#d3842e"));
		c2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		c2.setText("");
		this.add(c2);
		
		c3= new JButton();
		c3.setLayout(null);
		c3.setBounds(375, 550, 300, 50);
		c3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		c3.setForeground(Color.decode("#162550"));
		c3.setBackground(Color.decode("#d3842e"));
		c3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		c3.setText("");
		this.add(c3);
		
		c4= new JButton();
		c4.setLayout(null);
		c4.setBounds(900, 550, 300, 50);
		c4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		c4.setForeground(Color.decode("#162550"));
		c4.setBackground(Color.decode("#d3842e"));
		c4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		c4.setText("");
		this.add(c4);
		
		this.restart= new JButton();
		this.restart.setLayout(null);
		this.restart.setBounds(1200, 5, 160, 40);
		this.restart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		this.restart.setForeground(Color.decode("#162550"));
		this.restart.setBackground(Color.decode("#d3842e"));
		this.restart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		this.restart.setText("Restart Game");
		this.add(restart);
		
		JLabel oneL = new JLabel();
		oneL.setText("Flag 1" );
		oneL.setBounds(1200, 50, 160, 40);
		oneL.setLayout(null);
		oneL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		oneL.setForeground(Color.decode("#5f2e1e"));
		this.add(oneL);
		
	}

}