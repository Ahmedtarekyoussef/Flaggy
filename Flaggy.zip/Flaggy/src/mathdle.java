import java.util.Random;

public class mathdle {

public static void display (String [] x) {

for (int i=0;i<x.length;i++) {
System.out.print(x[i] + " ");	
}
	
}
	
public static void same(String a, String b) {
String flag;
if(a.length()==b.length()) {	
flag= "true";	
for (int i=0;i<a.length();i++) {
char aa=a.charAt(i);
char bb=b.charAt(i);
if(aa!=bb) {
flag="false";
}
}
}
else {
flag="false";	
}
System.out.println(flag);
}

public static void main(String [] args) {
	
/*Random r = new Random();	
String [] answer = new String [8];

int b1=r.nextInt(5);
String [] first= {"5","6","7","8","9"};
answer[0]=first[b1];


if(answer[0]=="0") {
	String [] intOp = new String [2];
	String [] op = {"+","-","X",};
	int opChoose = r.nextInt(3);
	intOp [0]= op[opChoose];
	b1=r.nextInt(10);
	intOp [1]= Integer.toString(b1);
	int b2=r.nextInt(2);
	answer[1]=intOp[b2];	
}
else
{	
String [] intOp = new String [2];
String [] op = {"+","-","X","/"};
int opChoose = r.nextInt(4);
intOp [0]= op[opChoose];
b1=r.nextInt(10);
intOp [1]= Integer.toString(b1);
int b2=r.nextInt(2);
answer[1]=intOp[b2];
}

if(answer[1]== "+" || answer[1]== "-" || answer[1]== "X" || answer[1]== "/" ) {

if(answer[1]== "/") {
String [] second= {"1","2","3","4","5","6","7","8","9"};
b1=r.nextInt(9);
answer[2]=second[b1];
}

else {
	b1=r.nextInt(10);
	answer[2]=Integer.toString(b1);;	
}

int x1= Integer.parseInt(answer[0]);
int x2= Integer.parseInt(answer[2]);

while((answer[1]=="-"&& x1<x2)||(answer[1]=="/" && x1%x2 != 0)) {
	
	if(answer[1]== "/") {
		String [] second= {"1","2","3","4","5","6","7","8","9"};
		b1=r.nextInt(9);
		answer[2]=second[b1];
		x2= Integer.parseInt(answer[2]);
		System.out.println(answer[0] +" " +answer[1]+" " +answer[2]);
		}
	else {
	b1=r.nextInt(10);
	answer[2]=Integer.toString(b1);	
	x2= Integer.parseInt(answer[2]);
	System.out.println(answer[0] +" " +answer[1]+" " +answer[2]);}
}
	
}
else
{	
String [] intOp = new String [2];
String [] op = {"+","-","X","/"};
int opChoose = r.nextInt(4);
intOp [0]= op[opChoose];
b1=r.nextInt(10);
intOp [1]= Integer.toString(b1);
int b2=r.nextInt(2);
answer[2]=intOp[b2];
}
display(answer);
	
} */
	
same("DE65110101015047219335","DE65110101015047219335");	
	
}}	