import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ten extends JPanel {
	
JButton tenRestart;
JButton tenC1;
JButton tenC2;
JButton tenC3;
JButton tenC4;	
JLabel tenL;

public ten() {
	
	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	tenC1= new JButton();
	tenC1.setLayout(null);
	tenC1.setBounds(375, 400, 400, 50);
	tenC1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	tenC1.setForeground(Color.decode("#162550"));
	tenC1.setBackground(Color.decode("#d3842e"));
	tenC1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	tenC1.setText("");
	this.add(tenC1);
	
	tenC2= new JButton();
	tenC2.setLayout(null);
	tenC2.setBounds(900, 400, 300, 50);
	tenC2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	tenC2.setForeground(Color.decode("#162550"));
	tenC2.setBackground(Color.decode("#d3842e"));
	tenC2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	tenC2.setText("");
	this.add(tenC2);
	
	tenC3= new JButton();
	tenC3.setLayout(null);
	tenC3.setBounds(375, 550, 300, 50);
	tenC3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	tenC3.setForeground(Color.decode("#162550"));
	tenC3.setBackground(Color.decode("#d3842e"));
	tenC3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	tenC3.setText("");
	this.add(tenC3);
	
	tenC4= new JButton();
	tenC4.setLayout(null);
	tenC4.setBounds(900, 550, 300, 50);
	tenC4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	tenC4.setForeground(Color.decode("#162550"));
	tenC4.setBackground(Color.decode("#d3842e"));
	tenC4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	tenC4.setText("");
	this.add(tenC4);
	
	this.tenRestart= new JButton();
	this.tenRestart.setLayout(null);
	this.tenRestart.setBounds(1200, 5, 160, 40);
	this.tenRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.tenRestart.setForeground(Color.decode("#162550"));
	this.tenRestart.setBackground(Color.decode("#d3842e"));
	this.tenRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.tenRestart.setText("Restart Game");
	this.add(tenRestart);
	
	JLabel tenL = new JLabel();
	tenL.setText("Flag 10" );
	tenL.setBounds(1200, 50, 160, 40);
	tenL.setLayout(null);
	tenL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	tenL.setForeground(Color.decode("#5f2e1e"));
	this.add(tenL);

}
}
