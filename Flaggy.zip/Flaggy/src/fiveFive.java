import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class fiveFive extends JPanel {
	
JButton fiveFiveCont;	
JButton fiveFiveRestart;

public fiveFive() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.fiveFiveCont= new JButton();
	this.fiveFiveCont.setLayout(null);
	this.fiveFiveCont.setBounds(900, 550, 300, 50);
	this.fiveFiveCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.fiveFiveCont.setForeground(Color.decode("#540a04"));
	this.fiveFiveCont.setBackground(Color.decode("#d3842e"));
	this.fiveFiveCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.fiveFiveCont.setText("Go To Flag 6");
	this.add(fiveFiveCont);
	
	this.fiveFiveRestart= new JButton();
	this.fiveFiveRestart.setLayout(null);
	this.fiveFiveRestart.setBounds(1200, 5, 160, 40);
	this.fiveFiveRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.fiveFiveRestart.setForeground(Color.decode("#162550"));
	this.fiveFiveRestart.setBackground(Color.decode("#d3842e"));
	this.fiveFiveRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.fiveFiveRestart.setText("Restart Game");
	this.add(fiveFiveRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
}
	
}
