import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class three extends JPanel {
	
	JButton threeRestart;
	JButton threeC1;
	JButton threeC2;
	JButton threeC3;
	JButton threeC4;
	JLabel threeL;
	
	public three() {
	
		this.setLayout(null);
		this.setPreferredSize(new Dimension(1920,1080));
		this.setBackground(Color.decode("#e6c580"));
		
		threeC1= new JButton();
		threeC1.setLayout(null);
		threeC1.setBounds(375, 400, 400, 50);
		threeC1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		threeC1.setForeground(Color.decode("#162550"));
		threeC1.setBackground(Color.decode("#d3842e"));
		threeC1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		threeC1.setText("");
		this.add(threeC1);
		
		threeC2= new JButton();
		threeC2.setLayout(null);
		threeC2.setBounds(900, 400, 300, 50);
		threeC2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		threeC2.setForeground(Color.decode("#162550"));
		threeC2.setBackground(Color.decode("#d3842e"));
		threeC2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		threeC2.setText("");
		this.add(threeC2);
		
		threeC3= new JButton();
		threeC3.setLayout(null);
		threeC3.setBounds(375, 550, 300, 50);
		threeC3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		threeC3.setForeground(Color.decode("#162550"));
		threeC3.setBackground(Color.decode("#d3842e"));
		threeC3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		threeC3.setText("");
		this.add(threeC3);
		
		threeC4= new JButton();
		threeC4.setLayout(null);
		threeC4.setBounds(900, 550, 300, 50);
		threeC4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		threeC4.setForeground(Color.decode("#162550"));
		threeC4.setBackground(Color.decode("#d3842e"));
		threeC4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		threeC4.setText("");
		this.add(threeC4);
		
		this.threeRestart= new JButton();
		this.threeRestart.setLayout(null);
		this.threeRestart.setBounds(1200, 5, 160, 40);
		this.threeRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		this.threeRestart.setForeground(Color.decode("#162550"));
		this.threeRestart.setBackground(Color.decode("#d3842e"));
		this.threeRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		this.threeRestart.setText("Restart Game");
		this.add(threeRestart);
		
		JLabel threeL = new JLabel();
		threeL.setText("Flag 3" );
		threeL.setBounds(1200, 50, 160, 40);
		threeL.setLayout(null);
		threeL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		threeL.setForeground(Color.decode("#5f2e1e"));
		this.add(threeL);
		
	}

}