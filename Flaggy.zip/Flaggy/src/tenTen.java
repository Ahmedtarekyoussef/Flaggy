import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class tenTen extends JPanel {
	
JButton tenTenCont;	
JButton tenTenRestart;

public tenTen() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.tenTenCont= new JButton();
	this.tenTenCont.setLayout(null);
	this.tenTenCont.setBounds(900, 550, 300, 50);
	this.tenTenCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.tenTenCont.setForeground(Color.decode("#540a04"));
	this.tenTenCont.setBackground(Color.decode("#d3842e"));
	this.tenTenCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.tenTenCont.setText("Go To Flag 11");
	this.add(tenTenCont);
	
	this.tenTenRestart= new JButton();
	this.tenTenRestart.setLayout(null);
	this.tenTenRestart.setBounds(1200, 5, 160, 40);
	this.tenTenRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.tenTenRestart.setForeground(Color.decode("#162550"));
	this.tenTenRestart.setBackground(Color.decode("#d3842e"));
	this.tenTenRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.tenTenRestart.setText("Restart Game");
	this.add(tenTenRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
}
	
}
