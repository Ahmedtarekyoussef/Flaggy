import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class thirteenThirteen extends JPanel {
	
JButton thirteenThirteenCont;	
JButton thirteenThirteenRestart;

public thirteenThirteen() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.thirteenThirteenCont= new JButton();
	this.thirteenThirteenCont.setLayout(null);
	this.thirteenThirteenCont.setBounds(900, 550, 300, 50);
	this.thirteenThirteenCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.thirteenThirteenCont.setForeground(Color.decode("#540a04"));
	this.thirteenThirteenCont.setBackground(Color.decode("#d3842e"));
	this.thirteenThirteenCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.thirteenThirteenCont.setText("Go To Flag 14");
	this.add(thirteenThirteenCont);
	
	this.thirteenThirteenRestart= new JButton();
	this.thirteenThirteenRestart.setLayout(null);
	this.thirteenThirteenRestart.setBounds(1200, 5, 160, 40);
	this.thirteenThirteenRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.thirteenThirteenRestart.setForeground(Color.decode("#162550"));
	this.thirteenThirteenRestart.setBackground(Color.decode("#d3842e"));
	this.thirteenThirteenRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.thirteenThirteenRestart.setText("Restart Game");
	this.add(thirteenThirteenRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
}
	
}
