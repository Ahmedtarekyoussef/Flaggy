import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class threeThree extends JPanel {
	
JButton threeThreeCont;	
JButton threeThreeRestart;

public threeThree() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.threeThreeCont= new JButton();
	this.threeThreeCont.setLayout(null);
	this.threeThreeCont.setBounds(900, 550, 300, 50);
	this.threeThreeCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.threeThreeCont.setForeground(Color.decode("#540a04"));
	this.threeThreeCont.setBackground(Color.decode("#d3842e"));
	this.threeThreeCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.threeThreeCont.setText("Go To Flag 4");
	this.add(threeThreeCont);
	
	this.threeThreeRestart= new JButton();
	this.threeThreeRestart.setLayout(null);
	this.threeThreeRestart.setBounds(1200, 5, 160, 40);
	this.threeThreeRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.threeThreeRestart.setForeground(Color.decode("#162550"));
	this.threeThreeRestart.setBackground(Color.decode("#d3842e"));
	this.threeThreeRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.threeThreeRestart.setText("Restart Game");
	this.add(threeThreeRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
}
	
}
