import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class seven extends JPanel {
	
JButton sevenRestart;
JButton sevenC1;
JButton sevenC2;
JButton sevenC3;
JButton sevenC4;
JLabel sevenL;

public seven() {
	
	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	sevenC1= new JButton();
	sevenC1.setLayout(null);
	sevenC1.setBounds(375, 400, 400, 50);
	sevenC1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	sevenC1.setForeground(Color.decode("#162550"));
	sevenC1.setBackground(Color.decode("#d3842e"));
	sevenC1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	sevenC1.setText("");
	this.add(sevenC1);
	
	sevenC2= new JButton();
	sevenC2.setLayout(null);
	sevenC2.setBounds(900, 400, 300, 50);
	sevenC2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	sevenC2.setForeground(Color.decode("#162550"));
	sevenC2.setBackground(Color.decode("#d3842e"));
	sevenC2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	sevenC2.setText("");
	this.add(sevenC2);
	
	sevenC3= new JButton();
	sevenC3.setLayout(null);
	sevenC3.setBounds(375, 550, 300, 50);
	sevenC3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	sevenC3.setForeground(Color.decode("#162550"));
	sevenC3.setBackground(Color.decode("#d3842e"));
	sevenC3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	sevenC3.setText("");
	this.add(sevenC3);
	
	sevenC4= new JButton();
	sevenC4.setLayout(null);
	sevenC4.setBounds(900, 550, 300, 50);
	sevenC4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	sevenC4.setForeground(Color.decode("#162550"));
	sevenC4.setBackground(Color.decode("#d3842e"));
	sevenC4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	sevenC4.setText("");
	this.add(sevenC4);
	
	this.sevenRestart= new JButton();
	this.sevenRestart.setLayout(null);
	this.sevenRestart.setBounds(1200, 5, 160, 40);
	this.sevenRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.sevenRestart.setForeground(Color.decode("#162550"));
	this.sevenRestart.setBackground(Color.decode("#d3842e"));
	this.sevenRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.sevenRestart.setText("Restart Game");
	this.add(sevenRestart);
	
	JLabel sevenL = new JLabel();
	sevenL.setText("Flag 7" );
	sevenL.setBounds(1200, 50, 160, 40);
	sevenL.setLayout(null);
	sevenL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	sevenL.setForeground(Color.decode("#5f2e1e"));
	this.add(sevenL);

}
}
