import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class surePanel extends JPanel {

		JButton surePanelBack;
		JButton surePanelCont;
	
	public surePanel() {
	
		this.setLayout(null);
		this.setPreferredSize(new Dimension(1920,1080));
		this.setBackground(Color.decode("#e6c580"));
			
		this.surePanelBack= new JButton();
		this.surePanelBack.setBounds(10, 550, 100, 50);
		this.surePanelBack.setText("Back");
		this.surePanelBack.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		this.surePanelBack.setBorder(BorderFactory.createLineBorder(Color.decode("#97551c"), 5));
		this.surePanelBack.setBackground(Color.decode("#97551c"));
		this.add(surePanelBack);
		
		this.surePanelCont= new JButton();
		this.surePanelCont.setBounds(815, 400, 200, 50);
		this.surePanelCont.setText("Start Game");
		this.surePanelCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		this.surePanelCont.setBorder(BorderFactory.createLineBorder(Color.decode("#97551c"), 5));
		this.surePanelCont.setBackground(Color.decode("#97551c"));
		this.add(surePanelCont);
		
	}
	
}
