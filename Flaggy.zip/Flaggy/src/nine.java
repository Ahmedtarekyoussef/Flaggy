import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class nine extends JPanel {
	
JButton nineRestart;
JButton nineC1;
JButton nineC2;
JButton nineC3;
JButton nineC4;	
JLabel nineL;

public nine() {
	
	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	nineC1= new JButton();
	nineC1.setLayout(null);
	nineC1.setBounds(375, 400, 400, 50);
	nineC1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	nineC1.setForeground(Color.decode("#162550"));
	nineC1.setBackground(Color.decode("#d3842e"));
	nineC1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	nineC1.setText("");
	this.add(nineC1);
	
	nineC2= new JButton();
	nineC2.setLayout(null);
	nineC2.setBounds(900, 400, 300, 50);
	nineC2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	nineC2.setForeground(Color.decode("#162550"));
	nineC2.setBackground(Color.decode("#d3842e"));
	nineC2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	nineC2.setText("");
	this.add(nineC2);
	
	nineC3= new JButton();
	nineC3.setLayout(null);
	nineC3.setBounds(375, 550, 300, 50);
	nineC3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	nineC3.setForeground(Color.decode("#162550"));
	nineC3.setBackground(Color.decode("#d3842e"));
	nineC3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	nineC3.setText("");
	this.add(nineC3);
	
	nineC4= new JButton();
	nineC4.setLayout(null);
	nineC4.setBounds(900, 550, 300, 50);
	nineC4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	nineC4.setForeground(Color.decode("#162550"));
	nineC4.setBackground(Color.decode("#d3842e"));
	nineC4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	nineC4.setText("");
	this.add(nineC4);
	
	this.nineRestart= new JButton();
	this.nineRestart.setLayout(null);
	this.nineRestart.setBounds(1200, 5, 160, 40);
	this.nineRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.nineRestart.setForeground(Color.decode("#162550"));
	this.nineRestart.setBackground(Color.decode("#d3842e"));
	this.nineRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.nineRestart.setText("Restart Game");
	this.add(nineRestart);
	
	JLabel nineL = new JLabel();
	nineL.setText("Flag 9" );
	nineL.setBounds(1200, 50, 160, 40);
	nineL.setLayout(null);
	nineL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	nineL.setForeground(Color.decode("#5f2e1e"));
	this.add(nineL);

}
}
