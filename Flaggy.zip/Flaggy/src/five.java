import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class five extends JPanel {
	
JButton fiveRestart;
JButton fiveC1;
JButton fiveC2;
JButton fiveC3;
JButton fiveC4;	
JLabel fiveL;

public five() {
	
	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	fiveC1= new JButton();
	fiveC1.setLayout(null);
	fiveC1.setBounds(375, 400, 400, 50);
	fiveC1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	fiveC1.setForeground(Color.decode("#162550"));
	fiveC1.setBackground(Color.decode("#d3842e"));
	fiveC1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	fiveC1.setText("");
	this.add(fiveC1);
	
	fiveC2= new JButton();
	fiveC2.setLayout(null);
	fiveC2.setBounds(900, 400, 300, 50);
	fiveC2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	fiveC2.setForeground(Color.decode("#162550"));
	fiveC2.setBackground(Color.decode("#d3842e"));
	fiveC2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	fiveC2.setText("");
	this.add(fiveC2);
	
	fiveC3= new JButton();
	fiveC3.setLayout(null);
	fiveC3.setBounds(375, 550, 300, 50);
	fiveC3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	fiveC3.setForeground(Color.decode("#162550"));
	fiveC3.setBackground(Color.decode("#d3842e"));
	fiveC3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	fiveC3.setText("");
	this.add(fiveC3);
	
	fiveC4= new JButton();
	fiveC4.setLayout(null);
	fiveC4.setBounds(900, 550, 300, 50);
	fiveC4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	fiveC4.setForeground(Color.decode("#162550"));
	fiveC4.setBackground(Color.decode("#d3842e"));
	fiveC4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	fiveC4.setText("");
	this.add(fiveC4);
	
	this.fiveRestart= new JButton();
	this.fiveRestart.setLayout(null);
	this.fiveRestart.setBounds(1200, 5, 160, 40);
	this.fiveRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.fiveRestart.setForeground(Color.decode("#162550"));
	this.fiveRestart.setBackground(Color.decode("#d3842e"));
	this.fiveRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.fiveRestart.setText("Restart Game");
	this.add(fiveRestart);
	
	JLabel fiveL = new JLabel();
	fiveL.setText("Flag 5" );
	fiveL.setBounds(1200, 50, 160, 40);
	fiveL.setLayout(null);
	fiveL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	fiveL.setForeground(Color.decode("#5f2e1e"));
	this.add(fiveL);

}
}
