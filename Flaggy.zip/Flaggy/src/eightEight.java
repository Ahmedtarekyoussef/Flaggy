import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class eightEight extends JPanel {
	
JButton eightEightCont;	
JButton eightEightRestart;

public eightEight() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.eightEightCont= new JButton();
	this.eightEightCont.setLayout(null);
	this.eightEightCont.setBounds(900, 550, 300, 50);
	this.eightEightCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.eightEightCont.setForeground(Color.decode("#540a04"));
	this.eightEightCont.setBackground(Color.decode("#d3842e"));
	this.eightEightCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.eightEightCont.setText("Go To Flag 9");
	this.add(eightEightCont);
	
	this.eightEightRestart= new JButton();
	this.eightEightRestart.setLayout(null);
	this.eightEightRestart.setBounds(1200, 5, 160, 40);
	this.eightEightRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.eightEightRestart.setForeground(Color.decode("#162550"));
	this.eightEightRestart.setBackground(Color.decode("#d3842e"));
	this.eightEightRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.eightEightRestart.setText("Restart Game");
	this.add(eightEightRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
	
}
	
}
