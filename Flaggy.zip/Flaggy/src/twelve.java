import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class twelve extends JPanel {
	
JButton twelveRestart;
JButton twelveC1;
JButton twelveC2;
JButton twelveC3;
JButton twelveC4;	
JLabel twelveL;

public twelve() {
	
	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	twelveC1= new JButton();
	twelveC1.setLayout(null);
	twelveC1.setBounds(375, 400, 400, 50);
	twelveC1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	twelveC1.setForeground(Color.decode("#162550"));
	twelveC1.setBackground(Color.decode("#d3842e"));
	twelveC1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	twelveC1.setText("");
	this.add(twelveC1);
	
	twelveC2= new JButton();
	twelveC2.setLayout(null);
	twelveC2.setBounds(900, 400, 300, 50);
	twelveC2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	twelveC2.setForeground(Color.decode("#162550"));
	twelveC2.setBackground(Color.decode("#d3842e"));
	twelveC2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	twelveC2.setText("");
	this.add(twelveC2);
	
	twelveC3= new JButton();
	twelveC3.setLayout(null);
	twelveC3.setBounds(375, 550, 300, 50);
	twelveC3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	twelveC3.setForeground(Color.decode("#162550"));
	twelveC3.setBackground(Color.decode("#d3842e"));
	twelveC3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	twelveC3.setText("");
	this.add(twelveC3);
	
	twelveC4= new JButton();
	twelveC4.setLayout(null);
	twelveC4.setBounds(900, 550, 300, 50);
	twelveC4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	twelveC4.setForeground(Color.decode("#162550"));
	twelveC4.setBackground(Color.decode("#d3842e"));
	twelveC4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	twelveC4.setText("");
	this.add(twelveC4);
	
	this.twelveRestart= new JButton();
	this.twelveRestart.setLayout(null);
	this.twelveRestart.setBounds(1200, 5, 160, 40);
	this.twelveRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.twelveRestart.setForeground(Color.decode("#162550"));
	this.twelveRestart.setBackground(Color.decode("#d3842e"));
	this.twelveRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.twelveRestart.setText("Restart Game");
	this.add(twelveRestart);
	
	JLabel twelveL = new JLabel();
	twelveL.setText("Flag 12" );
	twelveL.setBounds(1200, 50, 160, 40);
	twelveL.setLayout(null);
	twelveL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	twelveL.setForeground(Color.decode("#5f2e1e"));
	this.add(twelveL);

}
}
