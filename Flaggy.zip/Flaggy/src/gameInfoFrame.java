import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class gameInfoFrame extends JPanel {
	
	JTextArea info;
	JButton gameInfoFrameBack;
	
	public gameInfoFrame() {
	//Panel
	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	
	//Info
	this.info = new JTextArea();
	this.info.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
	this.info.setLayout(null);
	this.info.setEditable(false);
	this.info.setBounds(500, 0, 100, 100);
	this.info.setText("ATY ATY");
	this.add(this.info, BorderLayout.NORTH);
	this.info.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
	this.info.setBackground(Color.decode("#d0b27b"));
	this.info.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.info.setForeground(Color.decode("#5f4021"));
	
	
	//GameButton On Screen
	this.gameInfoFrameBack= new JButton();
	this.gameInfoFrameBack.setBounds(680, 250, 200, 50);
	this.gameInfoFrameBack.setText("Back");
	this.gameInfoFrameBack.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.gameInfoFrameBack.setBorder(BorderFactory.createLineBorder(Color.decode("#97551c"), 5));
	this.gameInfoFrameBack.setBackground(Color.decode("#97551c"));
	this.add(gameInfoFrameBack);

		

}
}
