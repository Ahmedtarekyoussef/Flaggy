import javax.swing.JFrame;
import javax.swing.JPanel;

public class mainFrame extends JFrame {
	
	public mainFrame()
	{
		this.setExtendedState(MAXIMIZED_BOTH);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setTitle("Flaggy Game");

	}	

}
