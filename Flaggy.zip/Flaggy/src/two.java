import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class two extends JPanel {
	
	JButton twoRestart;
	JButton twoC1;
	JButton twoC2;
	JButton twoC3;
	JButton twoC4;
	JLabel twoL;
	
	public two() {
	
		this.setLayout(null);
		this.setPreferredSize(new Dimension(1920,1080));
		this.setBackground(Color.decode("#e6c580"));
		
		twoC1= new JButton();
		twoC1.setLayout(null);
		twoC1.setBounds(375, 400, 400, 50);
		twoC1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		twoC1.setForeground(Color.decode("#162550"));
		twoC1.setBackground(Color.decode("#d3842e"));
		twoC1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		twoC1.setText("");
		this.add(twoC1);
		
		twoC2= new JButton();
		twoC2.setLayout(null);
		twoC2.setBounds(900, 400, 300, 50);
		twoC2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		twoC2.setForeground(Color.decode("#162550"));
		twoC2.setBackground(Color.decode("#d3842e"));
		twoC2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		twoC2.setText("");
		this.add(twoC2);
		
		twoC3= new JButton();
		twoC3.setLayout(null);
		twoC3.setBounds(375, 550, 300, 50);
		twoC3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		twoC3.setForeground(Color.decode("#162550"));
		twoC3.setBackground(Color.decode("#d3842e"));
		twoC3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		twoC3.setText("");
		this.add(twoC3);
		
		twoC4= new JButton();
		twoC4.setLayout(null);
		twoC4.setBounds(900, 550, 300, 50);
		twoC4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		twoC4.setForeground(Color.decode("#162550"));
		twoC4.setBackground(Color.decode("#d3842e"));
		twoC4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		twoC4.setText("");
		this.add(twoC4);
		
		this.twoRestart= new JButton();
		this.twoRestart.setLayout(null);
		this.twoRestart.setBounds(1200, 5, 160, 40);
		this.twoRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		this.twoRestart.setForeground(Color.decode("#162550"));
		this.twoRestart.setBackground(Color.decode("#d3842e"));
		this.twoRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
		this.twoRestart.setText("Restart Game");
		this.add(twoRestart);
		
		JLabel twoL = new JLabel();
		twoL.setText("Flag 2" );
		twoL.setBounds(1200, 50, 160, 40);
		twoL.setLayout(null);
		twoL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		twoL.setForeground(Color.decode("#5f2e1e"));
		this.add(twoL);
		
	}

}