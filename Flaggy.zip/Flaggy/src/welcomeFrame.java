import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class welcomeFrame extends JPanel {

JLabel gameName;
JButton startGame;
JButton gameInfo;	
	
public welcomeFrame() {
		

			//Panel
			this.setLayout(null);
			this.setPreferredSize(new Dimension(1920,1080));
			this.setBackground(Color.decode("#e6c580"));
			
			
			//GameName on Screen
			this.gameName = new JLabel("Flaggy");
			this.gameName.setBounds(650, 60, 300,250 );
			this.gameName.setFont(new Font(Font.SERIF, Font.BOLD, 40));
			this.gameName.setForeground(Color.decode("#54110f"));
			this.add(gameName);
			
			
			//GameButton On Screen
			this.startGame= new JButton();
			this.startGame.setBounds(680, 250, 200, 50);
			this.startGame.setText("Start Game");
			this.startGame.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			this.startGame.setBorder(BorderFactory.createLineBorder(Color.decode("#97551c"), 5));
			this.startGame.setBackground(Color.decode("#97551c"));
			this.add(startGame);
			
			//gameInfo On Screen
			this.gameInfo= new JButton();
			this.gameInfo.setBounds(10, 550, 120, 50);
			this.gameInfo.setText("how to play");
			this.gameInfo.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			this.gameInfo.setBorder(BorderFactory.createLineBorder(Color.decode("#97551c"), 5));
			this.gameInfo.setBackground(Color.decode("#97551c"));
			this.add(gameInfo);
			
			this.setVisible(true);

}
}
