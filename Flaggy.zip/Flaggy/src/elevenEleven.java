import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class elevenEleven extends JPanel {
	
JButton elevenElevenCont;	
JButton elevenElevenRestart;

public elevenEleven() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.elevenElevenCont= new JButton();
	this.elevenElevenCont.setLayout(null);
	this.elevenElevenCont.setBounds(900, 550, 300, 50);
	this.elevenElevenCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.elevenElevenCont.setForeground(Color.decode("#540a04"));
	this.elevenElevenCont.setBackground(Color.decode("#d3842e"));
	this.elevenElevenCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.elevenElevenCont.setText("Go To Flag 12");
	this.add(elevenElevenCont);
	
	this.elevenElevenRestart= new JButton();
	this.elevenElevenRestart.setLayout(null);
	this.elevenElevenRestart.setBounds(1200, 5, 160, 40);
	this.elevenElevenRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.elevenElevenRestart.setForeground(Color.decode("#162550"));
	this.elevenElevenRestart.setBackground(Color.decode("#d3842e"));
	this.elevenElevenRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.elevenElevenRestart.setText("Restart Game");
	this.add(elevenElevenRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
}
	
}
