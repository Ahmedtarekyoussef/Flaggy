import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class eleven extends JPanel {
	
JButton elevenRestart;
JButton elevenC1;
JButton elevenC2;
JButton elevenC3;
JButton elevenC4;	
JLabel elevenL;

public eleven() {
	
	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	elevenC1= new JButton();
	elevenC1.setLayout(null);
	elevenC1.setBounds(375, 400, 400, 50);
	elevenC1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	elevenC1.setForeground(Color.decode("#162550"));
	elevenC1.setBackground(Color.decode("#d3842e"));
	elevenC1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	elevenC1.setText("");
	this.add(elevenC1);
	
	elevenC2= new JButton();
	elevenC2.setLayout(null);
	elevenC2.setBounds(900, 400, 300, 50);
	elevenC2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	elevenC2.setForeground(Color.decode("#162550"));
	elevenC2.setBackground(Color.decode("#d3842e"));
	elevenC2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	elevenC2.setText("");
	this.add(elevenC2);
	
	elevenC3= new JButton();
	elevenC3.setLayout(null);
	elevenC3.setBounds(375, 550, 300, 50);
	elevenC3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	elevenC3.setForeground(Color.decode("#162550"));
	elevenC3.setBackground(Color.decode("#d3842e"));
	elevenC3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	elevenC3.setText("");
	this.add(elevenC3);
	
	elevenC4= new JButton();
	elevenC4.setLayout(null);
	elevenC4.setBounds(900, 550, 300, 50);
	elevenC4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	elevenC4.setForeground(Color.decode("#162550"));
	elevenC4.setBackground(Color.decode("#d3842e"));
	elevenC4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	elevenC4.setText("");
	this.add(elevenC4);
	
	this.elevenRestart= new JButton();
	this.elevenRestart.setLayout(null);
	this.elevenRestart.setBounds(1200, 5, 160, 40);
	this.elevenRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.elevenRestart.setForeground(Color.decode("#162550"));
	this.elevenRestart.setBackground(Color.decode("#d3842e"));
	this.elevenRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.elevenRestart.setText("Restart Game");
	this.add(elevenRestart);
	
	JLabel elevenL = new JLabel();
	elevenL.setText("Flag 11" );
	elevenL.setBounds(1200, 50, 160, 40);
	elevenL.setLayout(null);
	elevenL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	elevenL.setForeground(Color.decode("#5f2e1e"));
	this.add(elevenL);

}
}
