import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class oneOne extends JPanel {
	
JButton oneOneCont;
JButton oneOneRestart;

public oneOne() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.oneOneCont= new JButton();
	this.oneOneCont.setLayout(null);
	this.oneOneCont.setBounds(900, 550, 300, 50);
	this.oneOneCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.oneOneCont.setForeground(Color.decode("#540a04"));
	this.oneOneCont.setBackground(Color.decode("#d3842e"));
	this.oneOneCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.oneOneCont.setText("Go To Flag 2");
	this.add(oneOneCont);
	
	this.oneOneRestart= new JButton();
	this.oneOneRestart.setLayout(null);
	this.oneOneRestart.setBounds(1200, 5, 160, 40);
	this.oneOneRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.oneOneRestart.setForeground(Color.decode("#162550"));
	this.oneOneRestart.setBackground(Color.decode("#d3842e"));
	this.oneOneRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.oneOneRestart.setText("Restart Game");
	this.add(oneOneRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
}

public static void main (String [] args) {
	
}
	
}
