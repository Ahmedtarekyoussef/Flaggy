import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import java.util.ArrayList;
import java.util.Random;

public class control implements ActionListener {
	
welcomeFrame welcomeFrame;
mainFrame mainFrame;
Dimension frameDimensions;
Dimension modDimension;
gameInfoFrame gameInfoFrame;
chooseLevelFrame chooseLevelFrame;
surePanel surePanel;
String l;
one one;
ArrayList<String> name = new ArrayList<String>();
Random xx2 = new Random();
Random xx3 = new Random();
Random xx4 = new Random();
Random r = new Random();
oneOne oneOne;
String c1Name;
String n1;
String n2;
String n3;
String n4;
two two;
twoTwo twoTwo;
String twoN1;
String twoN2;
String twoN3;
String twoN4;
String c2Name;
int ra;
int wa;
three three;
threeThree threeThree;
String c3Name;
String threeN1;
String threeN2;
String threeN3;
String threeN4;
four four;
String c4Name;
String fourN1;
String fourN2;
String fourN3;
String fourN4;
fourFour fourFour;
five five;
String c5Name;
String fiveN1;
String fiveN2;
String fiveN3;
String fiveN4;
fiveFive fiveFive;
six six;
String c6Name;
String sixN1;
String sixN2;
String sixN3;
String sixN4;
sixSix sixSix;
seven seven;
String c7Name;
String sevenN1;
String sevenN2;
String sevenN3;
String sevenN4;
sevenSeven sevenSeven;
eight eight;
String c8Name;
String eightN1;
String eightN2;
String eightN3;
String eightN4;
eightEight eightEight;
nine nine;
String nineN1;
String nineN2;
String nineN3;
String nineN4;
String c9Name;
nineNine nineNine;
ten ten;
String c10Name;
String tenN1;
String tenN2;
String tenN3;
String tenN4;
tenTen tenTen;
eleven eleven;
String capital;
String c11Name;
String elevenN1;
String elevenN2;
String elevenN3;
String elevenN4;
String choose;
elevenEleven elevenEleven;
twelve twelve;
String c12Name;
String twelveN1;
String twelveN2;
String twelveN3;
String twelveN4;
twelveTwelve twelveTwelve;
thirteen thirteen;
String c13Name;
String thirteenN1;
String thirteenN2;
String thirteenN3;
String thirteenN4;
thirteenThirteen thirteenThirteen;

public control() {
	
	this.mainFrame = new mainFrame();
	this.frameDimensions = new Dimension(this.mainFrame.getWidth(), this.mainFrame.getHeight());
	this.modDimension = new Dimension(this.mainFrame.getWidth(), this.mainFrame.getHeight() - 100);
	this.welcomeFrame = new welcomeFrame();
	this.welcomeFrame.setPreferredSize(this.frameDimensions);
	this.mainFrame.add(welcomeFrame);
	
	welcomeFrame.startGame.addActionListener(this);
	welcomeFrame.gameInfo.addActionListener(this);
	
	this.gameInfoFrame = new gameInfoFrame();
	this.gameInfoFrame.setPreferredSize(this.frameDimensions);
	this.gameInfoFrame.gameInfoFrameBack.addActionListener(this);
	
	this.chooseLevelFrame = new chooseLevelFrame();
	this.chooseLevelFrame.setPreferredSize(this.frameDimensions);
	this.chooseLevelFrame.chooseLevelFrameBack.addActionListener(this);
	this.chooseLevelFrame.levelOne.addActionListener(this);
	this.chooseLevelFrame.levelTwo.addActionListener(this);
	this.chooseLevelFrame.levelThree.addActionListener(this);
	this.chooseLevelFrame.levelFour.addActionListener(this);
	
	this.surePanel = new surePanel();
	this.surePanel.setPreferredSize(this.frameDimensions);
	this.surePanel.surePanelCont.addActionListener(this);
	this.surePanel.surePanelBack.addActionListener(this);
	
	this.one = new one();
	this.one.setPreferredSize(this.frameDimensions);
	this.one.restart.addActionListener(this);
	this.one.c1.addActionListener(this);
	this.one.c2.addActionListener(this);
	this.one.c3.addActionListener(this);
	this.one.c4.addActionListener(this);
	
	this.oneOne = new oneOne();
	this.oneOne.setPreferredSize(this.frameDimensions);
	this.oneOne.oneOneCont.addActionListener(this);
	this.oneOne.oneOneRestart.addActionListener(this);
	
	this.two = new two();
	this.two.setPreferredSize(this.frameDimensions);
	this.two.twoRestart.addActionListener(this);
	this.two.twoC1.addActionListener(this);
	this.two.twoC2.addActionListener(this);
	this.two.twoC3.addActionListener(this);
	this.two.twoC4.addActionListener(this);
	
	this.twoTwo = new twoTwo();
	this.twoTwo.setPreferredSize(this.frameDimensions);
	this.twoTwo.twoTwoCont.addActionListener(this);
	this.twoTwo.twoTwoRestart.addActionListener(this);
	
	this.three = new three();
	this.three.setPreferredSize(this.frameDimensions);
	this.three.threeRestart.addActionListener(this);
	this.three.threeC1.addActionListener(this);
	this.three.threeC2.addActionListener(this);
	this.three.threeC3.addActionListener(this);
	this.three.threeC4.addActionListener(this);
	
	this.threeThree = new threeThree();
	this.threeThree.setPreferredSize(this.frameDimensions);
	this.threeThree.threeThreeCont.addActionListener(this);
	this.threeThree.threeThreeRestart.addActionListener(this);
	
	this.four = new four();
	this.four.setPreferredSize(this.frameDimensions);
	this.four.fourRestart.addActionListener(this);
	this.four.fourC1.addActionListener(this);
	this.four.fourC2.addActionListener(this);
	this.four.fourC3.addActionListener(this);
	this.four.fourC4.addActionListener(this);
	
	this.fourFour = new fourFour();
	this.fourFour.setPreferredSize(this.frameDimensions);
	this.fourFour.fourFourCont.addActionListener(this);
	this.fourFour.fourFourRestart.addActionListener(this);
	
	this.five = new five();
	this.five.setPreferredSize(this.frameDimensions);
	this.five.fiveRestart.addActionListener(this);
	this.five.fiveC1.addActionListener(this);
	this.five.fiveC2.addActionListener(this);
	this.five.fiveC3.addActionListener(this);
	this.five.fiveC4.addActionListener(this);
	
	this.fiveFive = new fiveFive();
	this.fiveFive.setPreferredSize(this.frameDimensions);
	this.fiveFive.fiveFiveCont.addActionListener(this);
	this.fiveFive.fiveFiveRestart.addActionListener(this);
	
	this.six = new six();
	this.six.setPreferredSize(this.frameDimensions);
	this.six.sixRestart.addActionListener(this);
	this.six.sixC1.addActionListener(this);
	this.six.sixC2.addActionListener(this);
	this.six.sixC3.addActionListener(this);
	this.six.sixC4.addActionListener(this);
	
	this.sixSix = new sixSix();
	this.sixSix.setPreferredSize(this.frameDimensions);
	this.sixSix.sixSixCont.addActionListener(this);
	this.sixSix.sixSixRestart.addActionListener(this);
	
	this.mainFrame.revalidate();
	this.mainFrame.repaint();
	
	this.seven = new seven();
	this.seven.setPreferredSize(this.frameDimensions);
	this.seven.sevenRestart.addActionListener(this);
	this.seven.sevenC1.addActionListener(this);
	this.seven.sevenC2.addActionListener(this);
	this.seven.sevenC3.addActionListener(this);
	this.seven.sevenC4.addActionListener(this);
	
	this.sevenSeven = new sevenSeven();
	this.sevenSeven.setPreferredSize(this.frameDimensions);
	this.sevenSeven.sevenSevenCont.addActionListener(this);
	this.sevenSeven.sevenSevenRestart.addActionListener(this);
	
	this.eight = new eight();
	this.eight.setPreferredSize(this.frameDimensions);
	this.eight.eightRestart.addActionListener(this);
	this.eight.eightC1.addActionListener(this);
	this.eight.eightC2.addActionListener(this);
	this.eight.eightC3.addActionListener(this);
	this.eight.eightC4.addActionListener(this);
	
	this.eightEight = new eightEight();
	this.eightEight.setPreferredSize(this.frameDimensions);
	this.eightEight.eightEightCont.addActionListener(this);
	this.eightEight.eightEightRestart.addActionListener(this);
	
	this.nine = new nine();
	this.nine.setPreferredSize(this.frameDimensions);
	this.nine.nineRestart.addActionListener(this);
	this.nine.nineC1.addActionListener(this);
	this.nine.nineC2.addActionListener(this);
	this.nine.nineC3.addActionListener(this);
	this.nine.nineC4.addActionListener(this);
	
	this.nineNine = new nineNine();
	this.nineNine.setPreferredSize(this.frameDimensions);
	this.nineNine.nineNineCont.addActionListener(this);
	this.nineNine.nineNineRestart.addActionListener(this);
	
	this.ten = new ten();
	this.ten.setPreferredSize(this.frameDimensions);
	this.ten.tenRestart.addActionListener(this);
	this.ten.tenC1.addActionListener(this);
	this.ten.tenC2.addActionListener(this);
	this.ten.tenC3.addActionListener(this);
	this.ten.tenC4.addActionListener(this);
	
	this.tenTen = new tenTen();
	this.tenTen.setPreferredSize(this.frameDimensions);
	this.tenTen.tenTenCont.addActionListener(this);
	this.tenTen.tenTenRestart.addActionListener(this);
	
	this.eleven = new eleven();
	this.eleven.setPreferredSize(this.frameDimensions);
	this.eleven.elevenRestart.addActionListener(this);
	this.eleven.elevenC1.addActionListener(this);
	this.eleven.elevenC2.addActionListener(this);
	this.eleven.elevenC3.addActionListener(this);
	this.eleven.elevenC4.addActionListener(this);
	
	this.elevenEleven = new elevenEleven();
	this.elevenEleven.setPreferredSize(this.frameDimensions);
	this.elevenEleven.elevenElevenCont.addActionListener(this);
	this.elevenEleven.elevenElevenRestart.addActionListener(this);
	
	this.twelve = new twelve();
	this.twelve.setPreferredSize(this.frameDimensions);
	this.twelve.twelveRestart.addActionListener(this);
	this.twelve.twelveC1.addActionListener(this);
	this.twelve.twelveC2.addActionListener(this);
	this.twelve.twelveC3.addActionListener(this);
	this.twelve.twelveC4.addActionListener(this);
	
	this.twelveTwelve = new twelveTwelve();
	this.twelveTwelve.setPreferredSize(this.frameDimensions);
	this.twelveTwelve.twelveTwelveCont.addActionListener(this);
	this.twelveTwelve.twelveTwelveRestart.addActionListener(this);
	
	this.thirteen = new thirteen();
	this.thirteen.setPreferredSize(this.frameDimensions);
	this.thirteen.thirteenRestart.addActionListener(this);
	this.thirteen.thirteenC1.addActionListener(this);
	this.thirteen.thirteenC2.addActionListener(this);
	this.thirteen.thirteenC3.addActionListener(this);
	this.thirteen.thirteenC4.addActionListener(this);
	
	this.thirteenThirteen = new thirteenThirteen();
	this.thirteenThirteen.setPreferredSize(this.frameDimensions);
	this.thirteenThirteen.thirteenThirteenCont.addActionListener(this);
	this.thirteenThirteen.thirteenThirteenRestart.addActionListener(this);

}

@Override
public void actionPerformed(ActionEvent e) {

	if(e.getSource() == welcomeFrame.gameInfo) {
		this.welcomeFrame.setVisible(false);
		this.gameInfoFrame.setVisible(true);
		this.mainFrame.add(gameInfoFrame);
	}	
	
	if(e.getSource() ==gameInfoFrame.gameInfoFrameBack) {
		this.gameInfoFrame.setVisible(false);
		this.welcomeFrame.setVisible(true);
	}	
	
	if(e.getSource() ==welcomeFrame.startGame) {
		this.welcomeFrame.setVisible(false);
		this.chooseLevelFrame.setVisible(true);
		this.mainFrame.add(chooseLevelFrame);
	}
	
	if(e.getSource() ==chooseLevelFrame.chooseLevelFrameBack) {
		this.chooseLevelFrame.setVisible(false);
		this.welcomeFrame.setVisible(true);
	}
	
	if(e.getSource() ==chooseLevelFrame.levelOne && this.chooseLevelFrame.userName.getText().equals("")) {
		
		JOptionPane.showMessageDialog(this.chooseLevelFrame, "Please Enter Your Name");
		
	}
	
	if(e.getSource() ==chooseLevelFrame.levelOne && this.chooseLevelFrame.userName.getText().length()>8) {
		
		JOptionPane.showMessageDialog(this.chooseLevelFrame, "Please enter no more than 8 characters !!");
		this.mainFrame.dispose();
		control c= new control();
	
	}
	
if(e.getSource() ==chooseLevelFrame.levelTwo && this.chooseLevelFrame.userName.getText().length()>8) {
		
		JOptionPane.showMessageDialog(this.chooseLevelFrame, "Please enter no more than 8 characters !!");
		this.mainFrame.dispose();
		control c= new control();
	
	}

if(e.getSource() ==chooseLevelFrame.levelThree && this.chooseLevelFrame.userName.getText().length()>8) {
	
	JOptionPane.showMessageDialog(this.chooseLevelFrame, "Please enter no more than 8 characters !!");
	this.mainFrame.dispose();
	control c= new control();

}

if(e.getSource() ==chooseLevelFrame.levelFour && this.chooseLevelFrame.userName.getText().length()>8) {
	
	JOptionPane.showMessageDialog(this.chooseLevelFrame, "Please enter no more than 8 characters !!");
	this.mainFrame.dispose();
	control c= new control();

}
	
	if(e.getSource() ==chooseLevelFrame.levelTwo && this.chooseLevelFrame.userName.getText().equals("")) {
		
		JOptionPane.showMessageDialog(this.chooseLevelFrame, "Please Enter Your Name");
		
	}
	
	if(e.getSource() ==chooseLevelFrame.levelThree && this.chooseLevelFrame.userName.getText().equals("")) {
		
		JOptionPane.showMessageDialog(this.chooseLevelFrame, "Please Enter Your Name");
		
	}
	
	if(e.getSource() ==chooseLevelFrame.levelFour && this.chooseLevelFrame.userName.getText().equals("")) {
		
		JOptionPane.showMessageDialog(this.chooseLevelFrame, "Please Enter Your Name");
		
	}
	
	if(e.getSource() ==chooseLevelFrame.levelOne && ! (this.chooseLevelFrame.userName.getText().equals(""))) {
		
		l= "Easy";
		this.chooseLevelFrame.setVisible(false);
		this.surePanel.setVisible(true);
		this.mainFrame.add(surePanel);
		
		JLabel playerInfo = new JLabel();
		playerInfo.setText("Hi" +" "+ this.chooseLevelFrame.userName.getText() + " "+ "! You have chosen the" +" " + l + " "+ "level. Are you sure you want to continue??" );
		playerInfo.setBounds(200, -35, 900, 600);
		playerInfo.setLayout(null);
		playerInfo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		playerInfo.setForeground(Color.decode("#5f2e1e"));
		this.surePanel.add(playerInfo);
		
	}
	
	if(e.getSource() ==chooseLevelFrame.levelTwo && !(this.chooseLevelFrame.userName.getText().equals(""))) {
		
		l="Medium";
		this.chooseLevelFrame.setVisible(false);
		this.surePanel.setVisible(true);
		this.mainFrame.add(surePanel);
		
		JLabel playerInfo = new JLabel();
		playerInfo.setText("Hi" +" "+ this.chooseLevelFrame.userName.getText() + " "+ "! You have chosen the" +" " + l + " "+ "level. Are you sure you want to continue??" );
		playerInfo.setBounds(200, -35, 900, 600);
		playerInfo.setLayout(null);
		playerInfo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		playerInfo.setForeground(Color.decode("#5f2e1e"));
		this.surePanel.add(playerInfo);
		
	}
	
	if(e.getSource() ==chooseLevelFrame.levelThree && !(this.chooseLevelFrame.userName.getText().equals(""))) {
		
		l="Hard";
		this.chooseLevelFrame.setVisible(false);
		this.surePanel.setVisible(true);
		this.mainFrame.add(surePanel);
		
		JLabel playerInfo = new JLabel();
		playerInfo.setText("Hi" +" "+ this.chooseLevelFrame.userName.getText() + " "+ "! You have chosen the" +" " + l + " "+ "level. Are you sure you want to continue??" );
		playerInfo.setBounds(200, -35, 900, 600);
		playerInfo.setLayout(null);
		playerInfo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		playerInfo.setForeground(Color.decode("#5f2e1e"));
		this.surePanel.add(playerInfo);
		
	}
	
	if(e.getSource() ==chooseLevelFrame.levelFour && ! (this.chooseLevelFrame.userName.getText().equals(""))) {
		
		l="Very Hard";
		this.chooseLevelFrame.setVisible(false);
		this.surePanel.setVisible(true);
		this.mainFrame.add(surePanel);
		
		JLabel playerInfo = new JLabel();
		playerInfo.setText("Hi" +" "+ this.chooseLevelFrame.userName.getText() + " "+ "! You have chosen the" +" " + l + " "+ "level. Are you sure you want to continue??" );
		playerInfo.setBounds(200, -35, 900, 600);
		playerInfo.setLayout(null);
		playerInfo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		playerInfo.setForeground(Color.decode("#5f2e1e"));
		this.surePanel.add(playerInfo);
		
	}
	
	if(e.getSource() ==surePanel.surePanelBack || e.getSource() ==threeThree.threeThreeRestart || e.getSource() ==four.fourRestart || e.getSource() ==fourFour.fourFourRestart || e.getSource() ==fiveFive.fiveFiveRestart || e.getSource() ==six.sixRestart 
			|| e.getSource() ==sixSix.sixSixRestart || e.getSource() ==seven.sevenRestart || e.getSource() ==sevenSeven.sevenSevenRestart
			|| e.getSource() ==eight.eightRestart  || e.getSource() ==eightEight.eightEightRestart || e.getSource() ==nine.nineRestart || e.getSource() ==nineNine.nineNineRestart
			|| e.getSource() ==ten.tenRestart || e.getSource() ==tenTen.tenTenRestart || e.getSource() ==eleven.elevenRestart || e.getSource() ==elevenEleven.elevenElevenRestart
			|| e.getSource() ==twelve.twelveRestart || e.getSource() ==thirteen.thirteenRestart || e.getSource() ==thirteenThirteen.thirteenThirteenRestart) {
		
		this.mainFrame.dispose();
		control c =new control ();

	}
	
	if(e.getSource() ==surePanel.surePanelCont) {
		this.surePanel.setVisible(false);
		this.one.setVisible(true);
		this.mainFrame.add(one);
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 0          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 15" );
		one.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
		
		String [] countryName = names(l);
		int i1=r.nextInt(31);
		c1Name= countryName[i1];
		JLabel c1Flag;
		c1Flag=new JLabel(new ImageIcon(c1Name+".png"));
		c1Flag.setBounds(50, 50, 1200, 350);
		one.add(c1Flag , BorderLayout.SOUTH);
		
		int x2=xx2.nextInt(31);
		if(x2==i1) {
		while(x2==i1) {
			x2=xx2.nextInt(31);	
		}
		}
		
		int x3=xx3.nextInt(31);
		if(x3==i1 || x3==x2) {
		while(x3==i1 || x3==x2) {
			x3=xx3.nextInt(31);	
		}
		}
		
		int x4=xx4.nextInt(31);
		if(x4==i1||x4==x2||x4==x3) {
		while(x4==i1||x4==x2||x4==x3) {
			x4=xx4.nextInt(31);	
		}
		}
		
		 n1=countryName[i1];
		 n2=countryName[x2];
		 n3=countryName[x3];
		 n4=countryName[x4];
		String[] mix= {n1,n2,n3,n4};
		int mix1=r.nextInt(4);
		n1=mix[mix1];
		int mix2=r.nextInt(4);
		n2=mix[mix2];
		while(n1==n2) {
			mix2=r.nextInt(4);
			n2=mix[mix2];	
		}
		int mix3=r.nextInt(4);
		n3=mix[mix3];
		while(n3==n1 || n3==n2) {
			mix3=r.nextInt(4);
			n3=mix[mix3];	
		}
		int mix4=r.nextInt(4);
		n4=mix[mix4];
		while(n4==n1 || n4==n2 || n4==n3) {
			mix4=r.nextInt(4);
			n4=mix[mix4];	
		}
		
		one.c1.setText(n1);
		one.c2.setText(n2);
		one.c3.setText(n3);
		one.c4.setText(n4);
		
		//String [] countryName = {"Algeria","Brazil","Canada","China","Denmark","Egypt","France","Germany","Italy","Japan"};
		int i2=r.nextInt(31);
		String trail = countryName[i2];
		while(trail==c1Name) {
		i2=r.nextInt(31);
		trail = countryName[i2];	
		}
		c2Name=trail;
		//c1Name= countryName[i1];
		JLabel c2Flag;
		c2Flag=new JLabel(new ImageIcon(c2Name+".png"));
		c2Flag.setBounds(50, 50, 1200, 350);
		two.add(c2Flag , BorderLayout.SOUTH);
		
		x2=r.nextInt(31);
		while(x2==i1 || x2==i2) {
		x2=r.nextInt(31);	
		}
		
		x3=r.nextInt(31);
		while(x3==i1 || x3==x2 || x3==i2) {
		x3=r.nextInt(31);	
		}
		
		x4=r.nextInt(31);
		while(x4==i1||x4==x2||x4==x3 || x4==i2) {
		x4=r.nextInt(31);	
		}
		
		  twoN1=countryName[i2];
		  twoN2=countryName[x2];
		  twoN3=countryName[x3];
		  twoN4=countryName[x4];
		String[] twoMix= {twoN1,twoN2,twoN3,twoN4};
		mix1=r.nextInt(4);
		twoN1=twoMix[mix1];
		mix2=r.nextInt(4);
		twoN2=twoMix[mix2];
		while(twoN1==twoN2) {
			mix2=r.nextInt(4);
			twoN2=twoMix[mix2];	
		}
		mix3=r.nextInt(4);
		twoN3=twoMix[mix3];
		while(twoN3==twoN1 || twoN3==twoN2) {
			mix3=r.nextInt(4);
			twoN3=twoMix[mix3];	
		}
		mix4=r.nextInt(4);
		twoN4=twoMix[mix4];
		while(twoN4==twoN1 || twoN4==twoN2 || twoN4==twoN3) {
			mix4=r.nextInt(4);
			twoN4=twoMix[mix4];	
		}
		
		two.twoC1.setText(twoN1);
		two.twoC2.setText(twoN2);
		two.twoC3.setText(twoN3);
		two.twoC4.setText(twoN4);
		
				//messi
				int i3=r.nextInt(31);
				trail = countryName[i3];
				while(trail==c1Name || trail==c2Name) {
				i3=r.nextInt(31);
				trail = countryName[i3];	
				}
				c3Name=trail; 
				//c1Name= countryName[i1];
				JLabel c3Flag;
				c3Flag=new JLabel(new ImageIcon(c3Name+".png"));
				c3Flag.setBounds(50, 50, 1200, 350);
				three.add(c3Flag , BorderLayout.SOUTH);
				
				x2=r.nextInt(31);
				while(x2==i1 || x2==i2 || x2==i3) {
				x2=r.nextInt(31);	
				}
				
				x3=r.nextInt(31);
				while(x3==i1 || x3==x2 || x3==i2 || x3==i3) {
				x3=r.nextInt(31);	
				}
				
				x4=r.nextInt(31);
				while(x4==i1||x4==x2||x4==x3 || x4==i2 || x4==i3) {
				x4=r.nextInt(31);	
				}
				
				  threeN1=countryName[i3];
				  threeN2=countryName[x2];
				  threeN3=countryName[x3];
				  threeN4=countryName[x4];
				String[] threeMix= {threeN1,threeN2,threeN3,threeN4};
				mix1=r.nextInt(4);
				threeN1=threeMix[mix1];
				mix2=r.nextInt(4);
				threeN2=threeMix[mix2];
				while(threeN1==threeN2) {
					mix2=r.nextInt(4);
					threeN2=threeMix[mix2];	
				}
				mix3=r.nextInt(4);
				threeN3=threeMix[mix3];
				while(threeN3==threeN1 || threeN3==threeN2) {
					mix3=r.nextInt(4);
					threeN3=threeMix[mix3];	
				}
				mix4=r.nextInt(4);
				threeN4=threeMix[mix4];
				while(threeN4==threeN1 || threeN4==threeN2 || threeN4==threeN3) {
					mix4=r.nextInt(4);
					threeN4=threeMix[mix4];	
				}
				
				three.threeC1.setText(threeN1);
				three.threeC2.setText(threeN2);
				three.threeC3.setText(threeN3);
				three.threeC4.setText(threeN4);
				
				//cr7
				int i4=r.nextInt(31);
				trail = countryName[i4];
				while(trail==c1Name || trail==c2Name || trail==c3Name) {
				i4=r.nextInt(31);
				trail = countryName[i4];	
				}
				c4Name=trail; 
				JLabel c4Flag;
				c4Flag=new JLabel(new ImageIcon(c4Name+".png"));
				c4Flag.setBounds(50, 50, 1200, 350);
				four.add(c4Flag , BorderLayout.SOUTH);
				
				x2=r.nextInt(31);
				while(x2==i1 || x2==i2 || x2==i3 || x2==i4) {
				x2=r.nextInt(31);	
				}
				
				x3=r.nextInt(31);
				while(x3==i1 || x3==x2 || x3==i2 || x3==i3 || x3==i4) {
				x3=r.nextInt(31);	
				}
				
				x4=r.nextInt(31);
				while(x4==i1||x4==x2||x4==x3 || x4==i2 || x4==i3 || x4==i4) {
				x4=r.nextInt(31);	
				}
				
				  fourN1=countryName[i4];
				  fourN2=countryName[x2];
				  fourN3=countryName[x3];
				  fourN4=countryName[x4];
				String[] fourMix= {fourN1,fourN2,fourN3,fourN4};
				mix1=r.nextInt(4);
				fourN1=fourMix[mix1];
				mix2=r.nextInt(4);
				fourN2=fourMix[mix2];
				while(fourN1==fourN2) {
					mix2=r.nextInt(4);
					fourN2=fourMix[mix2];	
				}
				mix3=r.nextInt(4);
				fourN3=fourMix[mix3];
				while(fourN3==fourN1 || fourN3==fourN2) {
					mix3=r.nextInt(4);
					fourN3=fourMix[mix3];	
				}
				mix4=r.nextInt(4);
				fourN4=fourMix[mix4];
				while(fourN4==fourN1 || fourN4==fourN2 || fourN4==fourN3) {
					mix4=r.nextInt(4);
					fourN4=fourMix[mix4];	
				}
				
				four.fourC1.setText(fourN1);
				four.fourC2.setText(fourN2);
				four.fourC3.setText(fourN3);
				four.fourC4.setText(fourN4);
				
				//cr7
				int i5=r.nextInt(31);
				trail = countryName[i5];
				while(trail==c1Name || trail==c2Name || trail==c3Name || trail==c4Name) {
				i5=r.nextInt(31);
				trail = countryName[i5];	
				}
				c5Name=trail; 
				JLabel c5Flag;
				c5Flag=new JLabel(new ImageIcon(c5Name+".png"));
				c5Flag.setBounds(50, 50, 1200, 350);
				five.add(c5Flag , BorderLayout.SOUTH);
				
				x2=r.nextInt(31);
				while(x2==i1 || x2==i2 || x2==i3 || x2==i4 || x2==i5) {
				x2=r.nextInt(31);	
				}
				
				x3=r.nextInt(31);
				while(x3==i1 || x3==x2 || x3==i2 || x3==i3 || x3==i4 || x3==i5) {
				x3=r.nextInt(31);	
				}
				
				x4=r.nextInt(31);
				while(x4==i1||x4==x2||x4==x3 || x4==i2 || x4==i3 || x4==i4 || x4==i5) {
				x4=r.nextInt(31);	
				}
				
				  fiveN1=countryName[i5];
				  fiveN2=countryName[x2];
				  fiveN3=countryName[x3];
				  fiveN4=countryName[x4];
				String[] fiveMix= {fiveN1,fiveN2,fiveN3,fiveN4};
				mix1=r.nextInt(4);
				fiveN1=fiveMix[mix1];
				mix2=r.nextInt(4);
				fiveN2=fiveMix[mix2];
				while(fiveN1==fiveN2) {
					mix2=r.nextInt(4);
					fiveN2=fiveMix[mix2];	
				}
				mix3=r.nextInt(4);
				fiveN3=fiveMix[mix3];
				while(fiveN3==fiveN1 || fiveN3==fiveN2) {
					mix3=r.nextInt(4);
					fiveN3=fiveMix[mix3];	
				}
				mix4=r.nextInt(4);
				fiveN4=fiveMix[mix4];
				while(fiveN4==fiveN1 || fiveN4==fiveN2 || fiveN4==fiveN3) {
					mix4=r.nextInt(4);
					fiveN4=fiveMix[mix4];	
				}
				
				five.fiveC1.setText(fiveN1);
				five.fiveC2.setText(fiveN2);
				five.fiveC3.setText(fiveN3);
				five.fiveC4.setText(fiveN4);
				
				//28/12
				int i6=r.nextInt(31);
				trail = countryName[i6];
				while(trail==c1Name || trail==c2Name || trail==c3Name || trail==c4Name || trail==c5Name ) {
				i6=r.nextInt(31);
				trail = countryName[i6];	
				}
				c6Name=trail; 
				JLabel c6Flag;
				c6Flag=new JLabel(new ImageIcon(c6Name+".png"));
				c6Flag.setBounds(50, 50, 1200, 350);
				six.add(c6Flag , BorderLayout.SOUTH);
				
				x2=r.nextInt(31);
				while(x2==i1 || x2==i2 || x2==i3 || x2==i4 || x2==i5 || x2==i6) {
				x2=r.nextInt(31);	
				}
				
				x3=r.nextInt(31);
				while(x3==i1 || x3==x2 || x3==i2 || x3==i3 || x3==i4 || x3==i5 || x3==i6) {
				x3=r.nextInt(31);	
				}
				
				x4=r.nextInt(31);
				while(x4==i1||x4==x2||x4==x3 || x4==i2 || x4==i3 || x4==i4 || x4==i5 || x4==i6) {
				x4=r.nextInt(31);	
				}
				
				  sixN1=countryName[i6];
				  sixN2=countryName[x2];
				  sixN3=countryName[x3];
				  sixN4=countryName[x4];
				String[] sixMix= {sixN1,sixN2,sixN3,sixN4};
				mix1=r.nextInt(4);
				sixN1=sixMix[mix1];
				mix2=r.nextInt(4);
				sixN2=sixMix[mix2];
				while(sixN1==sixN2) {
					mix2=r.nextInt(4);
					sixN2=sixMix[mix2];	
				}
				mix3=r.nextInt(4);
				sixN3=sixMix[mix3];
				while(sixN3==sixN1 || sixN3==sixN2) {
					mix3=r.nextInt(4);
					sixN3=sixMix[mix3];	
				}
				mix4=r.nextInt(4);
				sixN4=sixMix[mix4];
				while(sixN4==sixN1 || sixN4==sixN2 || sixN4==sixN3) {
					mix4=r.nextInt(4);
					sixN4=sixMix[mix4];	
				}
				
				six.sixC1.setText(sixN1);
				six.sixC2.setText(sixN2);
				six.sixC3.setText(sixN3);
				six.sixC4.setText(sixN4);
				
				//sevenaldo
				int i7=r.nextInt(31);
				trail = countryName[i7];
				while(trail==c1Name || trail==c2Name || trail==c3Name || trail==c4Name || trail==c5Name || trail==c6Name ) {
				i7=r.nextInt(31);
				trail = countryName[i7];	
				}
				c7Name=trail; 
				JLabel c7Flag;
				c7Flag=new JLabel(new ImageIcon(c7Name+".png"));
				c7Flag.setBounds(50, 50, 1200, 350);
				seven.add(c7Flag , BorderLayout.SOUTH);
				
				x2=r.nextInt(31);
				while(x2==i1 || x2==i2 || x2==i3 || x2==i4 || x2==i5 || x2==i6 || x2==i7) {
				x2=r.nextInt(31);	
				}
				
				x3=r.nextInt(31);
				while(x3==i1 || x3==x2 || x3==i2 || x3==i3 || x3==i4 || x3==i5 || x3==i6 || x3==i7) {
				x3=r.nextInt(31);	
				}
				
				x4=r.nextInt(31);
				while(x4==i1||x4==x2||x4==x3 || x4==i2 || x4==i3 || x4==i4 || x4==i5 || x4==i6 || x4==i7) {
				x4=r.nextInt(31);	
				}
				
				sevenN1=countryName[i7];
				sevenN2=countryName[x2];
				sevenN3=countryName[x3];
				sevenN4=countryName[x4];
				String[] sevenMix= {sevenN1,sevenN2,sevenN3,sevenN4};
				mix1=r.nextInt(4);
				sevenN1=sevenMix[mix1];
				mix2=r.nextInt(4);
				sevenN2=sevenMix[mix2];
				while(sevenN1==sevenN2) {
					mix2=r.nextInt(4);
					sevenN2=sevenMix[mix2];	
				}
				mix3=r.nextInt(4);
				sevenN3=sevenMix[mix3];
				while(sevenN3==sevenN1 || sevenN3==sevenN2) {
					mix3=r.nextInt(4);
					sevenN3=sevenMix[mix3];	
				}
				mix4=r.nextInt(4);
				sevenN4=sevenMix[mix4];
				while(sevenN4==sevenN1 || sevenN4==sevenN2 || sevenN4==sevenN3) {
					mix4=r.nextInt(4);
					sevenN4=sevenMix[mix4];	
				}
				
				seven.sevenC1.setText(sevenN1);
				seven.sevenC2.setText(sevenN2);
				seven.sevenC3.setText(sevenN3);
				seven.sevenC4.setText(sevenN4);
				
				//3/1/2022
				int i8=r.nextInt(31);
				trail = countryName[i8];
				while(trail==c1Name || trail==c2Name || trail==c3Name || trail==c4Name || trail==c5Name || trail==c6Name || trail==c7Name ) {
				i8=r.nextInt(31);
				trail = countryName[i8];	
				}
				c8Name=trail; 
				JLabel c8Flag;
				c8Flag=new JLabel(new ImageIcon(c8Name+".png"));
				c8Flag.setBounds(50, 50, 1200, 350);
				eight.add(c8Flag , BorderLayout.SOUTH);
				
				x2=r.nextInt(31);
				while(x2==i1 || x2==i2 || x2==i3 || x2==i4 || x2==i5 || x2==i6 || x2==i7 || x2==i8) {
				x2=r.nextInt(31);	
				}
				
				x3=r.nextInt(31);
				while(x3==i1 || x3==x2 || x3==i2 || x3==i3 || x3==i4 || x3==i5 || x3==i6 || x3==i7 || x3==i8) {
				x3=r.nextInt(31);	
				}
				
				x4=r.nextInt(31);
				while(x4==i1||x4==x2||x4==x3 || x4==i2 || x4==i3 || x4==i4 || x4==i5 || x4==i6 || x4==i7 || x4==i8) {
				x4=r.nextInt(31);	
				}
				
				eightN1=countryName[i8];
				eightN2=countryName[x2];
				eightN3=countryName[x3];
				eightN4=countryName[x4];
				String[] eightMix= {eightN1,eightN2,eightN3,eightN4};
				mix1=r.nextInt(4);
				eightN1=eightMix[mix1];
				mix2=r.nextInt(4);
				eightN2=eightMix[mix2];
				while(eightN1==eightN2) {
					mix2=r.nextInt(4);
					eightN2=eightMix[mix2];	
				}
				mix3=r.nextInt(4);
				eightN3=eightMix[mix3];
				while(eightN3==eightN1 || eightN3==eightN2) {
					mix3=r.nextInt(4);
					eightN3=eightMix[mix3];	
				}
				mix4=r.nextInt(4);
				eightN4=eightMix[mix4];
				while(eightN4==eightN1 || eightN4==eightN2 || eightN4==eightN3) {
					mix4=r.nextInt(4);
					eightN4=eightMix[mix4];	
				}
				
				eight.eightC1.setText(eightN1);
				eight.eightC2.setText(eightN2);
				eight.eightC3.setText(eightN3);
				eight.eightC4.setText(eightN4);
				
				//6/1/2022
				int i9=r.nextInt(31);
				trail = countryName[i9];
				while(trail==c1Name || trail==c2Name || trail==c3Name || trail==c4Name || trail==c5Name || trail==c6Name || trail==c7Name
						|| trail==c8Name) {
				i9=r.nextInt(31);
				trail = countryName[i9];	
				}
				c9Name=trail; 
				JLabel c9Flag;
				c9Flag=new JLabel(new ImageIcon(c9Name+".png"));
				c9Flag.setBounds(50, 50, 1200, 350);
				nine.add(c9Flag , BorderLayout.SOUTH);
				
				x2=r.nextInt(31);
				while(x2==i1 || x2==i2 || x2==i3 || x2==i4 || x2==i5 || x2==i6 || x2==i7 || x2==i8 || x2==i9) {
				x2=r.nextInt(31);	
				}
				
				x3=r.nextInt(31);
				while(x3==i1 || x3==x2 || x3==i2 || x3==i3 || x3==i4 || x3==i5 || x3==i6 || x3==i7 || x3==i8 || x3==i9) {
				x3=r.nextInt(31);	
				}
				
				x4=r.nextInt(31);
				while(x4==i1||x4==x2||x4==x3 || x4==i2 || x4==i3 || x4==i4 || x4==i5 || x4==i6 || x4==i7 || x4==i8 || x4==i9) {
				x4=r.nextInt(31);	
				}
				
				nineN1=countryName[i9];
				nineN2=countryName[x2];
				nineN3=countryName[x3];
				nineN4=countryName[x4];
				String[] nineMix= {nineN1,nineN2,nineN3,nineN4};
				mix1=r.nextInt(4);
				nineN1=nineMix[mix1];
				mix2=r.nextInt(4);
				nineN2=nineMix[mix2];
				while(nineN1==nineN2) {
					mix2=r.nextInt(4);
					nineN2=nineMix[mix2];	
				}
				mix3=r.nextInt(4);
				nineN3=nineMix[mix3];
				while(nineN3==nineN1 || nineN3==nineN2) {
					mix3=r.nextInt(4);
					nineN3=nineMix[mix3];	
				}
				mix4=r.nextInt(4);
				nineN4=nineMix[mix4];
				while(nineN4==nineN1 || nineN4==nineN2 || nineN4==nineN3) {
					mix4=r.nextInt(4);
					nineN4=nineMix[mix4];	
				}
				
				nine.nineC1.setText(nineN1);
				nine.nineC2.setText(nineN2);
				nine.nineC3.setText(nineN3);
				nine.nineC4.setText(nineN4);
				
				//23/1/2022
				int i10=r.nextInt(31);
				trail = countryName[i10];
				while(trail==c1Name || trail==c2Name || trail==c3Name || trail==c4Name || trail==c5Name || trail==c6Name || trail==c7Name
						|| trail==c8Name || trail==c9Name) {
				i10=r.nextInt(31);
				trail = countryName[i10];	
				}
				c10Name=trail; 
				JLabel c10Flag;
				c10Flag=new JLabel(new ImageIcon(c10Name+".png"));
				c10Flag.setBounds(50, 50, 1200, 350);
				ten.add(c10Flag , BorderLayout.SOUTH);
				
				x2=r.nextInt(31);
				while(x2==i1 || x2==i2 || x2==i3 || x2==i4 || x2==i5 || x2==i6 || x2==i7 || x2==i8 || x2==i9 || x2==i10) {
				x2=r.nextInt(31);	
				}
				
				x3=r.nextInt(31);
				while(x3==i1 || x3==x2 || x3==i2 || x3==i3 || x3==i4 || x3==i5 || x3==i6 || x3==i7 || x3==i8 || x3==i9 || x3==i10) {
				x3=r.nextInt(31);	
				}
				
				x4=r.nextInt(31);
				while(x4==i1||x4==x2||x4==x3 || x4==i2 || x4==i3 || x4==i4 || x4==i5 || x4==i6 || x4==i7 || x4==i8 || x4==i9 || x4==i10) {
				x4=r.nextInt(31);	
				}
				
				tenN1=countryName[i10];
				tenN2=countryName[x2];
				tenN3=countryName[x3];
				tenN4=countryName[x4];
				String[] tenMix= {tenN1,tenN2,tenN3,tenN4};
				mix1=r.nextInt(4);
				tenN1=tenMix[mix1];
				mix2=r.nextInt(4);
				tenN2=tenMix[mix2];
				while(tenN1==tenN2) {
					mix2=r.nextInt(4);
					tenN2=tenMix[mix2];	
				}
				mix3=r.nextInt(4);
				tenN3=tenMix[mix3];
				while(tenN3==tenN1 || tenN3==tenN2) {
					mix3=r.nextInt(4);
					tenN3=tenMix[mix3];	
				}
				mix4=r.nextInt(4);
				tenN4=tenMix[mix4];
				while(tenN4==tenN1 || tenN4==tenN2 || tenN4==tenN3) {
					mix4=r.nextInt(4);
					tenN4=tenMix[mix4];	
				}
				
				ten.tenC1.setText(tenN1);
				ten.tenC2.setText(tenN2);
				ten.tenC3.setText(tenN3);
				ten.tenC4.setText(tenN4);
				
				//26/1/2022
				int i11=r.nextInt(31);
				trail = countryName[i11];
				while(trail==c1Name || trail==c2Name || trail==c3Name || trail==c4Name || trail==c5Name || trail==c6Name || trail==c7Name
						|| trail==c8Name || trail==c9Name || trail==c10Name) {
				i11=r.nextInt(31);
				trail = countryName[i11];	
				}
				c11Name=trail; 
				JLabel c11Flag;
				c11Flag=new JLabel(new ImageIcon(c11Name+".png"));
				c11Flag.setBounds(50, 50, 1200, 350);
				eleven.add(c11Flag , BorderLayout.SOUTH);
				
				x2=r.nextInt(31);
				while(x2==i1 || x2==i2 || x2==i3 || x2==i4 || x2==i5 || x2==i6 || x2==i7 || x2==i8 || x2==i9 || x2==i10 || x2==i11) {
				x2=r.nextInt(31);	
				}
				
				x3=r.nextInt(31);
				while(x3==i1 || x3==x2 || x3==i2 || x3==i3 || x3==i4 || x3==i5 || x3==i6 || x3==i7 || x3==i8 || x3==i9 || x3==i10 || x3==i11) {
				x3=r.nextInt(31);	
				}
				
				x4=r.nextInt(31);
				while(x4==i1||x4==x2||x4==x3 || x4==i2 || x4==i3 || x4==i4 || x4==i5 || x4==i6 || x4==i7 || x4==i8 || x4==i9 || x4==i10 || x4==i11) {
				x4=r.nextInt(31);	
				}
				
				elevenN1=countryName[i11];
				elevenN2=countryName[x2];
				elevenN3=countryName[x3];
				elevenN4=countryName[x4];
				String[] elevenMix= {elevenN1,elevenN2,elevenN3,elevenN4};
				mix1=r.nextInt(4);
				elevenN1=elevenMix[mix1];
				mix2=r.nextInt(4);
				elevenN2=elevenMix[mix2];
				while(elevenN1==elevenN2) {
					mix2=r.nextInt(4);
					elevenN2=elevenMix[mix2];	
				}
				mix3=r.nextInt(4);
				elevenN3=elevenMix[mix3];
				while(elevenN3==elevenN1 || elevenN3==elevenN2) {
					mix3=r.nextInt(4);
					elevenN3=elevenMix[mix3];	
				}
				mix4=r.nextInt(4);
				elevenN4=elevenMix[mix4];
				while(elevenN4==elevenN1 || elevenN4==elevenN2 || elevenN4==elevenN3) {
					mix4=r.nextInt(4);
					elevenN4=elevenMix[mix4];	
				}
				
				eleven.elevenC1.setText(elevenN1);
				eleven.elevenC2.setText(elevenN2);
				eleven.elevenC3.setText(elevenN3);
				eleven.elevenC4.setText(elevenN4);
				
				int i12=r.nextInt(31);
				trail = countryName[i12];
				while(trail==c1Name || trail==c2Name || trail==c3Name || trail==c4Name || trail==c5Name || trail==c6Name || trail==c7Name
						|| trail==c8Name || trail==c9Name || trail==c10Name || trail==c11Name) {
				i12=r.nextInt(31);
				trail = countryName[i12];	
				}
				c12Name=trail; 
				JLabel c12Flag;
				c12Flag=new JLabel(new ImageIcon(c12Name+".png"));
				c12Flag.setBounds(50, 50, 1200, 350);
				twelve.add(c12Flag , BorderLayout.SOUTH);
				
				x2=r.nextInt(31);
				while(x2==i1 || x2==i2 || x2==i3 || x2==i4 || x2==i5 || x2==i6 || x2==i7 || x2==i8 || x2==i9 || x2==i10 || x2==i11 || x2==i12) {
				x2=r.nextInt(31);	
				}
				
				x3=r.nextInt(31);
				while(x3==i1 || x3==x2 || x3==i2 || x3==i3 || x3==i4 || x3==i5 || x3==i6 || x3==i7 || x3==i8 || x3==i9 || x3==i10 || x3==i11 || x3==i12) {
				x3=r.nextInt(31);	
				}
				
				x4=r.nextInt(31);
				while(x4==i1||x4==x2||x4==x3 || x4==i2 || x4==i3 || x4==i4 || x4==i5 || x4==i6 || x4==i7 || x4==i8 || x4==i9 || x4==i10 || x4==i11
						|| x4==i12) {
				x4=r.nextInt(31);	
				}
				
				twelveN1=countryName[i12];
				twelveN2=countryName[x2];
				twelveN3=countryName[x3];
				twelveN4=countryName[x4];
				String[] twelveMix= {twelveN1,twelveN2,twelveN3,twelveN4};
				mix1=r.nextInt(4);
				twelveN1=twelveMix[mix1];
				mix2=r.nextInt(4);
				twelveN2=twelveMix[mix2];
				while(twelveN1==twelveN2) {
					mix2=r.nextInt(4);
					twelveN2=twelveMix[mix2];	
				}
				mix3=r.nextInt(4);
				twelveN3=twelveMix[mix3];
				while(twelveN3==twelveN1 || twelveN3==twelveN2) {
					mix3=r.nextInt(4);
					twelveN3=twelveMix[mix3];	
				}
				mix4=r.nextInt(4);
				twelveN4=twelveMix[mix4];
				while(twelveN4==twelveN1 || twelveN4==twelveN2 || twelveN4==twelveN3) {
					mix4=r.nextInt(4);
					twelveN4=twelveMix[mix4];	
				}
				
				twelve.twelveC1.setText(twelveN1);
				twelve.twelveC2.setText(twelveN2);
				twelve.twelveC3.setText(twelveN3);
				twelve.twelveC4.setText(twelveN4);
				
				//9/4/2022
				int i13=r.nextInt(31);
				trail = countryName[i13];
				while(trail==c1Name || trail==c2Name || trail==c3Name || trail==c4Name || trail==c5Name || trail==c6Name || trail==c7Name
						|| trail==c8Name || trail==c9Name || trail==c10Name || trail==c11Name || trail==c12Name) {
				i13=r.nextInt(31);
				trail = countryName[i13];	
				}
				c13Name=trail; 
				JLabel c13Flag;
				c13Flag=new JLabel(new ImageIcon(c13Name+".png"));
				c13Flag.setBounds(50, 50, 1200, 350);
				thirteen.add(c13Flag , BorderLayout.SOUTH);
				
				x2=r.nextInt(31);
				while(x2==i1 || x2==i2 || x2==i3 || x2==i4 || x2==i5 || x2==i6 || x2==i7 || x2==i8 || x2==i9 || x2==i10 || x2==i11 || x2==i12
						|| x2==i13) {
				x2=r.nextInt(31);	
				}
				
				x3=r.nextInt(31);
				while(x3==i1 || x3==x2 || x3==i2 || x3==i3 || x3==i4 || x3==i5 || x3==i6 || x3==i7 || x3==i8 || x3==i9 || x3==i10 || x3==i11 || x3==i12
						|| x3==i13) {
				x3=r.nextInt(31);	
				}
				
				x4=r.nextInt(31);
				while(x4==i1||x4==x2||x4==x3 || x4==i2 || x4==i3 || x4==i4 || x4==i5 || x4==i6 || x4==i7 || x4==i8 || x4==i9 || x4==i10 || x4==i11
						|| x4==i12 || x4==i13) {
				x4=r.nextInt(31);	
				}
				
				thirteenN1=countryName[i13];
				thirteenN2=countryName[x2];
				thirteenN3=countryName[x3];
				thirteenN4=countryName[x4];
				String[] thriteenMix= {thirteenN1,thirteenN2,thirteenN3,thirteenN4};
				mix1=r.nextInt(4);
				thirteenN1=thriteenMix[mix1];
				mix2=r.nextInt(4);
				thirteenN2=thriteenMix[mix2];
				while(thirteenN1==thirteenN2) {
					mix2=r.nextInt(4);
					thirteenN2=thriteenMix[mix2];	
				}
				mix3=r.nextInt(4);
				thirteenN3=thriteenMix[mix3];
				while(thirteenN3==thirteenN1 || thirteenN3==thirteenN2) {
					mix3=r.nextInt(4);
					thirteenN3=thriteenMix[mix3];	
				}
				mix4=r.nextInt(4);
				thirteenN4=thriteenMix[mix4];
				while(thirteenN4==thirteenN1 || thirteenN4==thirteenN2 || thirteenN4==thirteenN3) {
					mix4=r.nextInt(4);
					thirteenN4=thriteenMix[mix4];	
				}
				
				thirteen.thirteenC1.setText(thirteenN1);
				thirteen.thirteenC2.setText(thirteenN2);
				thirteen.thirteenC3.setText(thirteenN3);
				thirteen.thirteenC4.setText(thirteenN4);
				
				JLabel flags1;
				flags1=new JLabel(new ImageIcon(c1Name+".png"));
				flags1.setBounds(150, 250, 500, 200);
				oneOne.add(flags1 , BorderLayout.SOUTH);
				
				JLabel names1 = new JLabel();
				names1.setText("Name: "+c1Name );
				names1.setBounds(10, 50, 250, 250);
				names1.setLayout(null);
				names1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names1.setForeground(Color.decode("#5f2e1e"));
				oneOne.add(names1);
				
				capital=capitals(l,i1);
				JLabel cap1 = new JLabel();
				cap1.setText("Capital: "+capital);
				cap1.setBounds(10, 450, 250, 250);
				cap1.setLayout(null);
				cap1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap1.setForeground(Color.decode("#5f2e1e"));
				oneOne.add(cap1);
				
				JLabel flags2;
				flags2=new JLabel(new ImageIcon(c2Name+".png"));
				flags2.setBounds(150, 250, 500, 200);
				twoTwo.add(flags2 , BorderLayout.SOUTH);
				
				JLabel names2 = new JLabel();
				names2.setText("Name: "+c2Name );
				names2.setBounds(10, 50, 250, 250);
				names2.setLayout(null);
				names2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names2.setForeground(Color.decode("#5f2e1e"));
				twoTwo.add(names2);
				
				capital=capitals(l,i2);
				JLabel cap2 = new JLabel();
				cap2.setText("Capital: "+capital);
				cap2.setBounds(10, 450, 250, 250);
				cap2.setLayout(null);
				cap2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap2.setForeground(Color.decode("#5f2e1e"));
				twoTwo.add(cap2);
				
				JLabel flags3;
				flags3=new JLabel(new ImageIcon(c3Name+".png"));
				flags3.setBounds(150, 250, 500, 200);
				threeThree.add(flags3 , BorderLayout.SOUTH);
				
				JLabel names3 = new JLabel();
				names3.setText("Name: "+c3Name );
				names3.setBounds(10, 50, 250, 250);
				names3.setLayout(null);
				names3.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names3.setForeground(Color.decode("#5f2e1e"));
				threeThree.add(names3);
				
				capital=capitals(l,i3);
				JLabel cap3 = new JLabel();
				cap3.setText("Capital: "+capital);
				cap3.setBounds(10, 450, 250, 250);
				cap3.setLayout(null);
				cap3.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap3.setForeground(Color.decode("#5f2e1e"));
				threeThree.add(cap3);
				
				JLabel flags4;
				flags4=new JLabel(new ImageIcon(c4Name+".png"));
				flags4.setBounds(150, 250, 500, 200);
				fourFour.add(flags4 , BorderLayout.SOUTH);
				
				JLabel names4 = new JLabel();
				names4.setText("Name: "+c4Name );
				names4.setBounds(10, 50, 250, 250);
				names4.setLayout(null);
				names4.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names4.setForeground(Color.decode("#5f2e1e"));
				fourFour.add(names4);
				
				capital=capitals(l,i4);
				JLabel cap4 = new JLabel();
				cap4.setText("Capital: "+capital);
				cap4.setBounds(10, 450, 250, 250);
				cap4.setLayout(null);
				cap4.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap4.setForeground(Color.decode("#5f2e1e"));
				fourFour.add(cap4);
				
				JLabel flags5;
				flags5=new JLabel(new ImageIcon(c5Name+".png"));
				flags5.setBounds(150, 250, 500, 200);
				fiveFive.add(flags5 , BorderLayout.SOUTH);
				
				JLabel names5 = new JLabel();
				names5.setText("Name: "+c5Name );
				names5.setBounds(10, 50, 250, 250);
				names5.setLayout(null);
				names5.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names5.setForeground(Color.decode("#5f2e1e"));
				fiveFive.add(names5);
				
				capital=capitals(l,i5);
				JLabel cap5 = new JLabel();
				cap5.setText("Capital: "+capital);
				cap5.setBounds(10, 450, 250, 250);
				cap5.setLayout(null);
				cap5.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap5.setForeground(Color.decode("#5f2e1e"));
				fiveFive.add(cap5);
				
				JLabel flags6;
				flags6=new JLabel(new ImageIcon(c6Name+".png"));
				flags6.setBounds(150, 250, 500, 200);
				sixSix.add(flags6 , BorderLayout.SOUTH);
				
				JLabel names6 = new JLabel();
				names6.setText("Name: "+c6Name );
				names6.setBounds(10, 50, 250, 250);
				names6.setLayout(null);
				names6.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names6.setForeground(Color.decode("#5f2e1e"));
				sixSix.add(names6);
				
				capital=capitals(l,i6);
				JLabel cap6 = new JLabel();
				cap6.setText("Capital: "+capital);
				cap6.setBounds(10, 450, 250, 250);
				cap6.setLayout(null);
				cap6.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap6.setForeground(Color.decode("#5f2e1e"));
				sixSix.add(cap6);
				
				JLabel flags7;
				flags7=new JLabel(new ImageIcon(c7Name+".png"));
				flags7.setBounds(150, 250, 500, 200);
				sevenSeven.add(flags7 , BorderLayout.SOUTH);
				
				JLabel names7 = new JLabel();
				names7.setText("Name: "+c7Name );
				names7.setBounds(10, 50, 250, 250);
				names7.setLayout(null);
				names7.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names7.setForeground(Color.decode("#5f2e1e"));
				sevenSeven.add(names7);
				
				capital=capitals(l,i7);
				JLabel cap7 = new JLabel();
				cap7.setText("Capital: "+capital);
				cap7.setBounds(10, 450, 250, 250);
				cap7.setLayout(null);
				cap7.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap7.setForeground(Color.decode("#5f2e1e"));
				sevenSeven.add(cap7);
				
				JLabel flags8;
				flags8=new JLabel(new ImageIcon(c8Name+".png"));
				flags8.setBounds(150, 250, 500, 200);
				eightEight.add(flags8 , BorderLayout.SOUTH);
				
				JLabel names8 = new JLabel();
				names8.setText("Name: "+c8Name );
				names8.setBounds(10, 50, 250, 250);
				names8.setLayout(null);
				names8.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names8.setForeground(Color.decode("#5f2e1e"));
				eightEight.add(names8);
				
				capital=capitals(l,i8);
				JLabel cap8 = new JLabel();
				cap8.setText("Capital: "+capital);
				cap8.setBounds(10, 450, 250, 250);
				cap8.setLayout(null);
				cap8.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap8.setForeground(Color.decode("#5f2e1e"));
				eightEight.add(cap8);
				
				JLabel flags9;
				flags9=new JLabel(new ImageIcon(c9Name+".png"));
				flags9.setBounds(150, 250, 500, 200);
				nineNine.add(flags9 , BorderLayout.SOUTH);
				
				JLabel names9 = new JLabel();
				names9.setText("Name: "+c9Name );
				names9.setBounds(10, 50, 250, 250);
				names9.setLayout(null);
				names9.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names9.setForeground(Color.decode("#5f2e1e"));
				nineNine.add(names9);
				
				capital=capitals(l,i9);
				JLabel cap9 = new JLabel();
				cap9.setText("Capital: "+capital);
				cap9.setBounds(10, 450, 250, 250);
				cap9.setLayout(null);
				cap9.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap9.setForeground(Color.decode("#5f2e1e"));
				nineNine.add(cap9);
				
				JLabel flags10;
				flags10=new JLabel(new ImageIcon(c10Name+".png"));
				flags10.setBounds(150, 250, 500, 200);
				tenTen.add(flags10 , BorderLayout.SOUTH);
				
				JLabel names10 = new JLabel();
				names10.setText("Name: "+c10Name );
				names10.setBounds(10, 50, 250, 250);
				names10.setLayout(null);
				names10.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names10.setForeground(Color.decode("#5f2e1e"));
				tenTen.add(names10);
				
				capital=capitals(l,i10);
				JLabel cap10 = new JLabel();
				cap10.setText("Capital: "+capital);
				cap10.setBounds(10, 450, 250, 250);
				cap10.setLayout(null);
				cap10.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap10.setForeground(Color.decode("#5f2e1e"));
				tenTen.add(cap10);
				
				JLabel flags11;
				flags11=new JLabel(new ImageIcon(c11Name+".png"));
				flags11.setBounds(150, 250, 500, 200);
				elevenEleven.add(flags11 , BorderLayout.SOUTH);
				
				JLabel names11 = new JLabel();
				names11.setText("Name: "+c11Name );
				names11.setBounds(10, 50, 250, 250);
				names11.setLayout(null);
				names11.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names11.setForeground(Color.decode("#5f2e1e"));
				elevenEleven.add(names11);
				
				capital=capitals(l,i11);
				JLabel cap11 = new JLabel();
				cap11.setText("Capital: "+capital); 
				cap11.setBounds(10, 450, 250, 250);
				cap11.setLayout(null);
				cap11.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap11.setForeground(Color.decode("#5f2e1e"));
				elevenEleven.add(cap11);
				
				//berlin
				JLabel flags12;
				flags12=new JLabel(new ImageIcon(c12Name+".png"));
				flags12.setBounds(150, 250, 500, 200);
				twelveTwelve.add(flags12 , BorderLayout.SOUTH);
				
				JLabel names12 = new JLabel();
				names12.setText("Name: "+c12Name );
				names12.setBounds(10, 50, 250, 250);
				names12.setLayout(null);
				names12.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names12.setForeground(Color.decode("#5f2e1e"));
				twelveTwelve.add(names12);
				
				capital=capitals(l,i12);
				JLabel cap12 = new JLabel();
				cap12.setText("Capital: "+capital);
				cap12.setBounds(10, 450, 250, 250);
				cap12.setLayout(null);
				cap12.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap12.setForeground(Color.decode("#5f2e1e"));
				twelveTwelve.add(cap12);
				
				//19/4
				JLabel flags13;
				flags13=new JLabel(new ImageIcon(c13Name+".png"));
				flags13.setBounds(150, 250, 500, 200);
				thirteenThirteen.add(flags13 , BorderLayout.SOUTH);
				
				JLabel names13 = new JLabel();
				names13.setText("Name: "+c13Name );
				names13.setBounds(10, 50, 250, 250);
				names13.setLayout(null);
				names13.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				names13.setForeground(Color.decode("#5f2e1e"));
				thirteenThirteen.add(names13);
				
				capital=capitals(l,i13);
				JLabel cap13 = new JLabel();
				cap13.setText("Capital: "+capital);
				cap13.setBounds(10, 450, 250, 250);
				cap13.setLayout(null);
				cap13.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
				cap13.setForeground(Color.decode("#5f2e1e"));
				thirteenThirteen.add(cap13);
		
	} 
		

	
	if(e.getSource() ==one.restart || e.getSource() ==oneOne.oneOneRestart || e.getSource() ==three.threeRestart || 
			e.getSource() ==twelveTwelve.twelveTwelveRestart ) {
		
		this.mainFrame.dispose();
		control c =new control ();

	}
	
	if(e.getSource() == one.c1 && n1==c1Name) {
		this.one.setVisible(false);
		this.oneOne.setVisible(true);
		this.mainFrame.add(oneOne);
		
		JLabel choose1 = new JLabel();
		choose1.setText("You Chose: "+n1 );
		choose1.setBounds(100, 500, 250, 250);
		choose1.setLayout(null);
		choose1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose1.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(choose1);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 1          " + "Right Answers: "+ ra + "          Wrong Answers :"+ wa +"          Flags Remaining: 14" );
		oneOne.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == one.c2 && n2==c1Name) {
		this.one.setVisible(false);
		this.oneOne.setVisible(true);
		this.mainFrame.add(oneOne);
		
		JLabel choose1 = new JLabel();
		choose1.setText("You Chose: "+n2 );
		choose1.setBounds(100, 500, 250, 250);
		choose1.setLayout(null);
		choose1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose1.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(choose1);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 1          " + "Right Answers: "+ ra + "          Wrong Answers :"+ wa +"          Flags Remaining: 14" );
		oneOne.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == one.c3&&n3==c1Name) {
		this.one.setVisible(false);
		this.oneOne.setVisible(true);
		this.mainFrame.add(oneOne);
		
		JLabel choose1 = new JLabel();
		choose1.setText("You Chose: "+n3 );
		choose1.setBounds(100, 500, 250, 250);
		choose1.setLayout(null);
		choose1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose1.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(choose1);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 1          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 14" );
		oneOne.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == one.c4&& n4==c1Name) {
		this.one.setVisible(false);
		this.oneOne.setVisible(true);
		this.mainFrame.add(oneOne);
		
		JLabel choose1 = new JLabel();
		choose1.setText("You Chose: "+n4 );
		choose1.setBounds(100, 500, 250, 250);
		choose1.setLayout(null);
		choose1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose1.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(choose1);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 1          " + "Right Answers: "+ ra + "          Wrong Answers :"+ wa +"          Flags Remaining: 14" );
		oneOne.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == one.c1 && ! (n1==c1Name)) {
		this.one.setVisible(false);
		this.oneOne.setVisible(true);
		this.mainFrame.add(oneOne);
		
		JLabel choose1 = new JLabel();
		choose1.setText("You Chose: "+n1 );
		choose1.setBounds(100, 500, 250, 250);
		choose1.setLayout(null);
		choose1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose1.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(choose1);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 1          " + "Right Answers: "+ ra + "          Wrong Answers :"+ wa +"          Flags Remaining: 14" );
		oneOne.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == one.c2 &&!(n2==c1Name)) {
		this.one.setVisible(false);
		this.oneOne.setVisible(true);
		this.mainFrame.add(oneOne);
		
		JLabel choose1 = new JLabel();
		choose1.setText("You Chose: "+n2 );
		choose1.setBounds(100, 500, 250, 250);
		choose1.setLayout(null);
		choose1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose1.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(choose1);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 1          " + "Right Answers: "+ ra + "          Wrong Answers :"+ wa +"          Flags Remaining: 14" );
		oneOne.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == one.c3&& ! (n3==c1Name)) {
		this.one.setVisible(false);
		this.oneOne.setVisible(true);
		this.mainFrame.add(oneOne);
		
		JLabel choose1 = new JLabel();
		choose1.setText("You Chose: "+n3 );
		choose1.setBounds(100, 500, 250, 250);
		choose1.setLayout(null);
		choose1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose1.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(choose1);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 1          " + "Right Answers: "+ ra + "          Wrong Answers :"+ wa +"          Flags Remaining: 14" );
		oneOne.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == one.c4&& ! (n4==c1Name)) {
		this.one.setVisible(false);
		this.oneOne.setVisible(true);
		this.mainFrame.add(oneOne);
		
		JLabel choose1 = new JLabel();
		choose1.setText("You Chose: "+n4 );
		choose1.setBounds(100, 500, 250, 250);
		choose1.setLayout(null);
		choose1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose1.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(choose1);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		oneOne.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 1          " + "Right Answers: "+ ra + "          Wrong Answers :"+ wa +"          Flags Remaining: 14" );
		oneOne.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == oneOne.oneOneCont) {
		this.oneOne.setVisible(false);
		this.two.setVisible(true);
		this.mainFrame.add(two);
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 1          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 14" );
		two.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
		
	}
	
	if(e.getSource() == two.twoRestart || e.getSource() == twoTwo.twoTwoRestart || e.getSource()== five.fiveRestart) {
		this.mainFrame.dispose();
		control c= new control();
		
	}
	
	//Here
	if(e.getSource() == two.twoC1 && twoN1==c2Name) {
		this.two.setVisible(false);
		this.twoTwo.setVisible(true);
		this.mainFrame.add(twoTwo);
		
		JLabel choose2 = new JLabel();
		choose2.setText("You Chose: "+twoN1 );
		choose2.setBounds(100, 500, 250, 250);
		choose2.setLayout(null);
		choose2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose2.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(choose2);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 2          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 13" );
		twoTwo.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == two.twoC2 && twoN2==c2Name) {
		this.two.setVisible(false);
		this.twoTwo.setVisible(true);
		this.mainFrame.add(twoTwo);
		
		JLabel choose2 = new JLabel();
		choose2.setText("You Chose: "+twoN2 );
		choose2.setBounds(100, 500, 250, 250);
		choose2.setLayout(null);
		choose2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose2.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(choose2);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 2          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 13" );
		twoTwo.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == two.twoC3 && twoN3==c2Name) {
		this.two.setVisible(false);
		this.twoTwo.setVisible(true);
		this.mainFrame.add(twoTwo);
		
		JLabel choose2 = new JLabel();
		choose2.setText("You Chose: "+twoN3 );
		choose2.setBounds(100, 500, 250, 250);
		choose2.setLayout(null);
		choose2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose2.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(choose2);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 2          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 13" );
		twoTwo.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == two.twoC4 && twoN4==c2Name) {
		this.two.setVisible(false);
		this.twoTwo.setVisible(true);
		this.mainFrame.add(twoTwo);
		
		JLabel choose2 = new JLabel();
		choose2.setText("You Chose: "+twoN4 );
		choose2.setBounds(100, 500, 250, 250);
		choose2.setLayout(null);
		choose2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose2.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(choose2);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 2          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 13" );
		twoTwo.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == two.twoC1 && ! (twoN1==c2Name)) {
		this.two.setVisible(false);
		this.twoTwo.setVisible(true);
		this.mainFrame.add(twoTwo);
		
		JLabel choose2 = new JLabel();
		choose2.setText("You Chose: "+twoN1 );
		choose2.setBounds(100, 500, 250, 250);
		choose2.setLayout(null);
		choose2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose2.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(choose2);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 2          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 13" );
		twoTwo.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == two.twoC2 && ! (twoN2==c2Name)) {
		this.two.setVisible(false);
		this.twoTwo.setVisible(true);
		this.mainFrame.add(twoTwo);
		
		JLabel choose2 = new JLabel();
		choose2.setText("You Chose: "+twoN2 );
		choose2.setBounds(100, 500, 250, 250);
		choose2.setLayout(null);
		choose2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose2.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(choose2);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 2          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 13" );
		twoTwo.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == two.twoC3 && ! (twoN3==c2Name)) {
		this.two.setVisible(false);
		this.twoTwo.setVisible(true);
		this.mainFrame.add(twoTwo);
		
		JLabel choose2 = new JLabel();
		choose2.setText("You Chose: "+twoN3 );
		choose2.setBounds(100, 500, 250, 250);
		choose2.setLayout(null);
		choose2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose2.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(choose2);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 2          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 13" );
		twoTwo.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == two.twoC4 && ! (twoN4==c2Name)) {
		this.two.setVisible(false);
		this.twoTwo.setVisible(true);
		this.mainFrame.add(twoTwo);
		
		JLabel choose2 = new JLabel();
		choose2.setText("You Chose: "+twoN4 );
		choose2.setBounds(100, 500, 250, 250);
		choose2.setLayout(null);
		choose2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose2.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(choose2);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		twoTwo.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 2          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 13" );
		twoTwo.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	//messi
	if(e.getSource() == three.threeC1 && threeN1==c3Name) {
		this.three.setVisible(false);
		this.threeThree.setVisible(true);
		this.mainFrame.add(threeThree);
		
		JLabel choose3 = new JLabel();
		choose3.setText("You Chose: "+threeN1 );
		choose3.setBounds(100, 500, 250, 250);
		choose3.setLayout(null);
		choose3.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose3.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(choose3);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 3          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 12" );
		threeThree.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == three.threeC2 && threeN2==c3Name) {
		this.three.setVisible(false);
		this.threeThree.setVisible(true);
		this.mainFrame.add(threeThree);
		
		JLabel choose3 = new JLabel();
		choose3.setText("You Chose: "+threeN2 );
		choose3.setBounds(100, 500, 250, 250);
		choose3.setLayout(null);
		choose3.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose3.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(choose3);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 3          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 12" );
		threeThree.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == three.threeC3 && threeN3==c3Name) {
		this.three.setVisible(false);
		this.threeThree.setVisible(true);
		this.mainFrame.add(threeThree);
		
		JLabel choose3 = new JLabel();
		choose3.setText("You Chose: "+threeN3 );
		choose3.setBounds(100, 500, 250, 250);
		choose3.setLayout(null);
		choose3.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose3.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(choose3);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 3          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 12" );
		threeThree.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == three.threeC4 && threeN4==c3Name) {
		this.three.setVisible(false);
		this.threeThree.setVisible(true);
		this.mainFrame.add(threeThree);
		
		JLabel choose3 = new JLabel();
		choose3.setText("You Chose: "+threeN4 );
		choose3.setBounds(100, 500, 250, 250);
		choose3.setLayout(null);
		choose3.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose3.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(choose3);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 3          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 12" );
		threeThree.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == three.threeC1 && ! (threeN1==c3Name)) {
		this.three.setVisible(false);
		this.threeThree.setVisible(true);
		this.mainFrame.add(threeThree);
		
		JLabel choose3 = new JLabel();
		choose3.setText("You Chose: "+threeN1 );
		choose3.setBounds(100, 500, 250, 250);
		choose3.setLayout(null);
		choose3.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose3.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(choose3);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 3          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 12" );
		threeThree.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == three.threeC2 && ! (threeN2==c3Name)) {
		this.three.setVisible(false);
		this.threeThree.setVisible(true);
		this.mainFrame.add(threeThree);
		
		JLabel choose3 = new JLabel();
		choose3.setText("You Chose: "+threeN2 );
		choose3.setBounds(100, 500, 250, 250);
		choose3.setLayout(null);
		choose3.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose3.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(choose3);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 3          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 12" );
		threeThree.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == three.threeC3 && ! (threeN3==c3Name)) {
		this.three.setVisible(false);
		this.threeThree.setVisible(true);
		this.mainFrame.add(threeThree);
		
		JLabel choose3 = new JLabel();
		choose3.setText("You Chose: "+threeN3 );
		choose3.setBounds(100, 500, 250, 250);
		choose3.setLayout(null);
		choose3.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose3.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(choose3);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 3          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 12" );
		threeThree.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == three.threeC4 && ! (threeN4==c3Name)) {
		this.three.setVisible(false);
		this.threeThree.setVisible(true);
		this.mainFrame.add(threeThree);
		
		JLabel choose3 = new JLabel();
		choose3.setText("You Chose: "+threeN4 );
		choose3.setBounds(100, 500, 250, 250);
		choose3.setLayout(null);
		choose3.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose3.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(choose3);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		threeThree.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 3          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 12" );
		threeThree.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == twoTwo.twoTwoCont) {
		this.twoTwo.setVisible(false);
		this.three.setVisible(true);
		this.mainFrame.add(three);
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 2          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 13" );
		three.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == threeThree.threeThreeCont) {
		this.threeThree.setVisible(false);
		this.four.setVisible(true);
		this.mainFrame.add(four);
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 3          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 12" );
		four.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
		
	}
	
	//CR7
	if(e.getSource() == four.fourC1 && fourN1==c4Name) {
		this.four.setVisible(false);
		this.fourFour.setVisible(true);
		this.mainFrame.add(fourFour);
		
		JLabel choose4 = new JLabel();
		choose4.setText("You Chose: "+fourN1 );
		choose4.setBounds(100, 500, 250, 250);
		choose4.setLayout(null);
		choose4.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose4.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(choose4);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 4          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 11" );
		fourFour.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == four.fourC2 && fourN2==c4Name) {
		this.four.setVisible(false);
		this.fourFour.setVisible(true);
		this.mainFrame.add(fourFour);
		
		JLabel choose4 = new JLabel();
		choose4.setText("You Chose: "+fourN2 );
		choose4.setBounds(100, 500, 250, 250);
		choose4.setLayout(null);
		choose4.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose4.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(choose4);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 4          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 11" );
		fourFour.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == four.fourC3 && fourN3==c4Name) {
		this.four.setVisible(false);
		this.fourFour.setVisible(true);
		this.mainFrame.add(fourFour);
		
		JLabel choose4 = new JLabel();
		choose4.setText("You Chose: "+fourN3 );
		choose4.setBounds(100, 500, 250, 250);
		choose4.setLayout(null);
		choose4.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose4.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(choose4);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 4          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 11" );
		fourFour.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == four.fourC4 && fourN4==c4Name) {
		this.four.setVisible(false);
		this.fourFour.setVisible(true);
		this.mainFrame.add(fourFour);
		
		JLabel choose4 = new JLabel();
		choose4.setText("You Chose: "+fourN4 );
		choose4.setBounds(100, 500, 250, 250);
		choose4.setLayout(null);
		choose4.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose4.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(choose4);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 4          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 11" );
		fourFour.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == four.fourC1 && ! (fourN1==c4Name)) {
		this.four.setVisible(false);
		this.fourFour.setVisible(true);
		this.mainFrame.add(fourFour);
		
		JLabel choose4 = new JLabel();
		choose4.setText("You Chose: "+fourN1 );
		choose4.setBounds(100, 500, 250, 250);
		choose4.setLayout(null);
		choose4.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose4.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(choose4);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 4          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 11" );
		fourFour.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == four.fourC2 && ! (fourN2==c4Name)) {
		this.four.setVisible(false);
		this.fourFour.setVisible(true);
		this.mainFrame.add(fourFour);
		
		JLabel choose4 = new JLabel();
		choose4.setText("You Chose: "+fourN2 );
		choose4.setBounds(100, 500, 250, 250);
		choose4.setLayout(null);
		choose4.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose4.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(choose4);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 4          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 11" );
		fourFour.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == four.fourC3 && ! (fourN3==c4Name)) {
		this.four.setVisible(false);
		this.fourFour.setVisible(true);
		this.mainFrame.add(fourFour);
		
		JLabel choose4 = new JLabel();
		choose4.setText("You Chose: "+fourN3 );
		choose4.setBounds(100, 500, 250, 250);
		choose4.setLayout(null);
		choose4.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose4.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(choose4);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 4          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 11" );
		fourFour.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == four.fourC4 && ! (fourN4==c4Name)) {
		this.four.setVisible(false);
		this.fourFour.setVisible(true);
		this.mainFrame.add(fourFour);
		
		JLabel choose4 = new JLabel();
		choose4.setText("You Chose: "+fourN4 );
		choose4.setBounds(100, 500, 250, 250);
		choose4.setLayout(null);
		choose4.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose4.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(choose4);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fourFour.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 4          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 11" );
		fourFour.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == fourFour.fourFourCont) {
		this.fourFour.setVisible(false);
		this.five.setVisible(true);
		this.mainFrame.add(five);
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 4          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 11" );
		five.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
		
	}
	
	//26/12
	if(e.getSource() == five.fiveC1 && fiveN1==c5Name) {
		this.five.setVisible(false);
		this.fiveFive.setVisible(true);
		this.mainFrame.add(fiveFive);
		
		JLabel choose5 = new JLabel();
		choose5.setText("You Chose: "+fiveN1 );
		choose5.setBounds(100, 500, 250, 250);
		choose5.setLayout(null);
		choose5.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose5.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(choose5);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 5          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 10" );
		fiveFive.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == five.fiveC2 && fiveN2==c5Name) {
		this.five.setVisible(false);
		this.fiveFive.setVisible(true);
		this.mainFrame.add(fiveFive);
		
		JLabel choose5 = new JLabel();
		choose5.setText("You Chose: "+fiveN2 );
		choose5.setBounds(100, 500, 250, 250);
		choose5.setLayout(null);
		choose5.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose5.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(choose5);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 5          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 10" );
		fiveFive.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == five.fiveC3 && fiveN3==c5Name) {
		this.five.setVisible(false);
		this.fiveFive.setVisible(true);
		this.mainFrame.add(fiveFive);
		
		JLabel choose5 = new JLabel();
		choose5.setText("You Chose: "+fiveN3 );
		choose5.setBounds(100, 500, 250, 250);
		choose5.setLayout(null);
		choose5.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose5.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(choose5);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 5          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 10" );
		fiveFive.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == five.fiveC4 && fiveN4==c5Name) {
		this.five.setVisible(false);
		this.fiveFive.setVisible(true);
		this.mainFrame.add(fiveFive);
		
		JLabel choose5 = new JLabel();
		choose5.setText("You Chose: "+fiveN4 );
		choose5.setBounds(100, 500, 250, 250);
		choose5.setLayout(null);
		choose5.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose5.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(choose5);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 5          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 10" );
		fiveFive.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == five.fiveC1 && ! (fiveN1==c5Name)) {
		this.five.setVisible(false);
		this.fiveFive.setVisible(true);
		this.mainFrame.add(fiveFive);
		
		JLabel choose5 = new JLabel();
		choose5.setText("You Chose: "+fiveN1 );
		choose5.setBounds(100, 500, 250, 250);
		choose5.setLayout(null);
		choose5.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose5.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(choose5);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 5          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 10" );
		fiveFive.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == five.fiveC2 && ! (fiveN2==c5Name)) {
		this.five.setVisible(false);
		this.fiveFive.setVisible(true);
		this.mainFrame.add(fiveFive);
		
		JLabel choose5 = new JLabel();
		choose5.setText("You Chose: "+fiveN2 );
		choose5.setBounds(100, 500, 250, 250);
		choose5.setLayout(null);
		choose5.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose5.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(choose5);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 5          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 10" );
		fiveFive.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == five.fiveC3 && ! (fiveN3==c5Name)) {
		this.five.setVisible(false);
		this.fiveFive.setVisible(true);
		this.mainFrame.add(fiveFive);
		
		JLabel choose5 = new JLabel();
		choose5.setText("You Chose: "+fiveN3 );
		choose5.setBounds(100, 500, 250, 250);
		choose5.setLayout(null);
		choose5.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose5.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(choose5);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 5          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 10" );
		fiveFive.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == five.fiveC4 && ! (fiveN4==c5Name)) {
		this.five.setVisible(false);
		this.fiveFive.setVisible(true);
		this.mainFrame.add(fiveFive);
		
		JLabel choose5 = new JLabel();
		choose5.setText("You Chose: "+fiveN4 );
		choose5.setBounds(100, 500, 250, 250);
		choose5.setLayout(null);
		choose5.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose5.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(choose5);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		fiveFive.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 5          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 10" );
		fiveFive.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == fiveFive.fiveFiveCont) {
		this.fiveFive.setVisible(false);
		this.six.setVisible(true);
		this.mainFrame.add(six);
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 5          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 10" );
		six.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
		
	}
	
	//29/12
	if(e.getSource() == six.sixC1 && sixN1==c6Name) {
		this.six.setVisible(false);
		this.sixSix.setVisible(true);
		this.mainFrame.add(sixSix);
		
		JLabel choose6 = new JLabel();
		choose6.setText("You Chose: "+sixN1 );
		choose6.setBounds(100, 500, 250, 250);
		choose6.setLayout(null);
		choose6.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose6.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(choose6);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 6          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 9" );
		sixSix.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == six.sixC2 && sixN2==c6Name) {
		this.six.setVisible(false);
		this.sixSix.setVisible(true);
		this.mainFrame.add(sixSix);
		
		JLabel choose6 = new JLabel();
		choose6.setText("You Chose: "+sixN2 );
		choose6.setBounds(100, 500, 250, 250);
		choose6.setLayout(null);
		choose6.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose6.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(choose6);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 6          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 9" );
		sixSix.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == six.sixC3 && sixN3==c6Name) {
		this.six.setVisible(false);
		this.sixSix.setVisible(true);
		this.mainFrame.add(sixSix);
		
		JLabel choose6 = new JLabel();
		choose6.setText("You Chose: "+sixN3 );
		choose6.setBounds(100, 500, 250, 250);
		choose6.setLayout(null);
		choose6.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose6.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(choose6);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 6          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 9" );
		sixSix.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == six.sixC4 && sixN4==c6Name) {
		this.six.setVisible(false);
		this.sixSix.setVisible(true);
		this.mainFrame.add(sixSix);
		
		JLabel choose6 = new JLabel();
		choose6.setText("You Chose: "+sixN4 );
		choose6.setBounds(100, 500, 250, 250);
		choose6.setLayout(null);
		choose6.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose6.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(choose6);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 6          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 9" );
		sixSix.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == six.sixC1 && ! (sixN1==c6Name)) {
		this.six.setVisible(false);
		this.sixSix.setVisible(true);
		this.mainFrame.add(sixSix);
		
		JLabel choose6 = new JLabel();
		choose6.setText("You Chose: "+sixN1 );
		choose6.setBounds(100, 500, 250, 250);
		choose6.setLayout(null);
		choose6.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose6.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(choose6);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 6          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 9" );
		sixSix.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == six.sixC2 && ! (sixN2==c6Name)) {
		this.six.setVisible(false);
		this.sixSix.setVisible(true);
		this.mainFrame.add(sixSix);
		
		JLabel choose6 = new JLabel();
		choose6.setText("You Chose: "+sixN2 );
		choose6.setBounds(100, 500, 250, 250);
		choose6.setLayout(null);
		choose6.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose6.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(choose6);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 6          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 9" );
		sixSix.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == six.sixC3 && ! (sixN3==c6Name)) {
		this.six.setVisible(false);
		this.sixSix.setVisible(true);
		this.mainFrame.add(sixSix);
		
		JLabel choose6 = new JLabel();
		choose6.setText("You Chose: "+sixN3 );
		choose6.setBounds(100, 500, 250, 250);
		choose6.setLayout(null);
		choose6.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose6.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(choose6);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 6          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 9" );
		sixSix.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == six.sixC4 && ! (sixN4==c6Name)) {
		this.six.setVisible(false);
		this.sixSix.setVisible(true);
		this.mainFrame.add(sixSix);
		
		JLabel choose6 = new JLabel();
		choose6.setText("You Chose: "+sixN4 );
		choose6.setBounds(100, 500, 250, 250);
		choose6.setLayout(null);
		choose6.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose6.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(choose6);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sixSix.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 6          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 9" );
		sixSix.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == sixSix.sixSixCont) {
		this.sixSix.setVisible(false);
		this.seven.setVisible(true);
		this.mainFrame.add(seven);
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 6          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 9" );
		seven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
		
	}
	//31/12
	if(e.getSource() == seven.sevenC1 && sevenN1==c7Name) {
		this.seven.setVisible(false);
		this.sevenSeven.setVisible(true);
		this.mainFrame.add(sevenSeven);
		
		JLabel choose7 = new JLabel();
		choose7.setText("You Chose: "+sevenN1 );
		choose7.setBounds(100, 500, 250, 250);
		choose7.setLayout(null);
		choose7.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose7.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(choose7);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 7          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 8" );
		sevenSeven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == seven.sevenC2 && sevenN2==c7Name) {
		this.seven.setVisible(false);
		this.sevenSeven.setVisible(true);
		this.mainFrame.add(sevenSeven);
		
		JLabel choose7 = new JLabel();
		choose7.setText("You Chose: "+sevenN2 );
		choose7.setBounds(100, 500, 250, 250);
		choose7.setLayout(null);
		choose7.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose7.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(choose7);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 7          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 8" );
		sevenSeven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == seven.sevenC3 && sevenN3==c7Name) {
		this.seven.setVisible(false);
		this.sevenSeven.setVisible(true);
		this.mainFrame.add(sevenSeven);
		
		JLabel choose7 = new JLabel();
		choose7.setText("You Chose: "+sevenN3 );
		choose7.setBounds(100, 500, 250, 250);
		choose7.setLayout(null);
		choose7.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose7.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(choose7);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 7          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 8" );
		sevenSeven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == seven.sevenC4 && sevenN4==c7Name) {
		this.seven.setVisible(false);
		this.sevenSeven.setVisible(true);
		this.mainFrame.add(sevenSeven);
		
		JLabel choose7 = new JLabel();
		choose7.setText("You Chose: "+sevenN4 );
		choose7.setBounds(100, 500, 250, 250);
		choose7.setLayout(null);
		choose7.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose7.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(choose7);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 7          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 8" );
		sevenSeven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == seven.sevenC1 && ! (sevenN1==c7Name)) {
		this.seven.setVisible(false);
		this.sevenSeven.setVisible(true);
		this.mainFrame.add(sevenSeven);
		
		JLabel choose7 = new JLabel();
		choose7.setText("You Chose: "+sevenN1 );
		choose7.setBounds(100, 500, 250, 250);
		choose7.setLayout(null);
		choose7.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose7.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(choose7);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 7          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 8" );
		sevenSeven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == seven.sevenC2 && ! (sevenN2==c7Name)) {
		this.seven.setVisible(false);
		this.sevenSeven.setVisible(true);
		this.mainFrame.add(sevenSeven);
		
		JLabel choose7 = new JLabel();
		choose7.setText("You Chose: "+sevenN2 );
		choose7.setBounds(100, 500, 250, 250);
		choose7.setLayout(null);
		choose7.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose7.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(choose7);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 7          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 8" );
		sevenSeven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == seven.sevenC3 && ! (sevenN3==c7Name)) {
		this.seven.setVisible(false);
		this.sevenSeven.setVisible(true);
		this.mainFrame.add(sevenSeven);
		
		JLabel choose7 = new JLabel();
		choose7.setText("You Chose: "+sevenN3 );
		choose7.setBounds(100, 500, 250, 250);
		choose7.setLayout(null);
		choose7.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose7.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(choose7);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 7          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 8" );
		sevenSeven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == seven.sevenC4 && ! (sevenN4==c7Name)) {
		this.seven.setVisible(false);
		this.sevenSeven.setVisible(true);
		this.mainFrame.add(sevenSeven);
		
		JLabel choose7 = new JLabel();
		choose7.setText("You Chose: "+sevenN4 );
		choose7.setBounds(100, 500, 250, 250);
		choose7.setLayout(null);
		choose7.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose7.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(choose7);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		sevenSeven.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 7          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 8" );
		sevenSeven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == sevenSeven.sevenSevenCont) {
		this.sevenSeven.setVisible(false);
		this.eight.setVisible(true);
		this.mainFrame.add(eight);
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 7          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 8" );
		eight.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
		
	}
	
	//4/1/2022
	if(e.getSource() == eight.eightC1 && eightN1==c8Name) {
		this.eight.setVisible(false);
		this.eightEight.setVisible(true);
		this.mainFrame.add(eightEight);
		
		JLabel choose8 = new JLabel();
		choose8.setText("You Chose: "+eightN1 );
		choose8.setBounds(100, 500, 250, 250);
		choose8.setLayout(null);
		choose8.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose8.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(choose8);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 8          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 7" );
		eightEight.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eight.eightC2 && eightN2==c8Name) {
		this.eight.setVisible(false);
		this.eightEight.setVisible(true);
		this.mainFrame.add(eightEight);
		
		JLabel choose8 = new JLabel();
		choose8.setText("You Chose: "+eightN2 );
		choose8.setBounds(100, 500, 250, 250);
		choose8.setLayout(null);
		choose8.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose8.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(choose8);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 8          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 7" );
		eightEight.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eight.eightC3 && eightN3==c8Name) {
		this.eight.setVisible(false);
		this.eightEight.setVisible(true);
		this.mainFrame.add(eightEight);
		
		JLabel choose8 = new JLabel();
		choose8.setText("You Chose: "+eightN3 );
		choose8.setBounds(100, 500, 250, 250);
		choose8.setLayout(null);
		choose8.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose8.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(choose8);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 8          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 7" );
		eightEight.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eight.eightC4 && eightN4==c8Name) {
		this.eight.setVisible(false);
		this.eightEight.setVisible(true);
		this.mainFrame.add(eightEight);
		
		JLabel choose8 = new JLabel();
		choose8.setText("You Chose: "+eightN4 );
		choose8.setBounds(100, 500, 250, 250);
		choose8.setLayout(null);
		choose8.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose8.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(choose8);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 8          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 7" );
		eightEight.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eight.eightC1 && ! (eightN1==c8Name)) {
		this.eight.setVisible(false);
		this.eightEight.setVisible(true);
		this.mainFrame.add(eightEight);
		
		JLabel choose8 = new JLabel();
		choose8.setText("You Chose: "+eightN1 );
		choose8.setBounds(100, 500, 250, 250);
		choose8.setLayout(null);
		choose8.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose8.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(choose8);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 8          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 7" );
		eightEight.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eight.eightC2 && ! (eightN2==c8Name)) {
		this.eight.setVisible(false);
		this.eightEight.setVisible(true);
		this.mainFrame.add(eightEight);
		
		JLabel choose8 = new JLabel();
		choose8.setText("You Chose: "+eightN2 );
		choose8.setBounds(100, 500, 250, 250);
		choose8.setLayout(null);
		choose8.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose8.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(choose8);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 8          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 7" );
		eightEight.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eight.eightC3 && ! (eightN3==c8Name)) {
		this.eight.setVisible(false);
		this.eightEight.setVisible(true);
		this.mainFrame.add(eightEight);
		
		JLabel choose8 = new JLabel();
		choose8.setText("You Chose: "+eightN3 );
		choose8.setBounds(100, 500, 250, 250);
		choose8.setLayout(null);
		choose8.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose8.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(choose8);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 8          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 7" );
		eightEight.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eight.eightC4 && ! (eightN4==c8Name)) {
		this.eight.setVisible(false);
		this.eightEight.setVisible(true);
		this.mainFrame.add(eightEight);
		
		JLabel choose8 = new JLabel();
		choose8.setText("You Chose: "+eightN4 );
		choose8.setBounds(100, 500, 250, 250);
		choose8.setLayout(null);
		choose8.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose8.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(choose8);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		eightEight.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 8          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 7" );
		eightEight.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eightEight.eightEightCont) {
		this.eightEight.setVisible(false);
		this.nine.setVisible(true);
		this.mainFrame.add(nine);
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 8          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 7" );
		nine.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
		
	}
	
	//6/1/2022 
	if(e.getSource() == nine.nineC1 && nineN1==c9Name) {
		this.nine.setVisible(false);
		this.nineNine.setVisible(true);
		this.mainFrame.add(nineNine);
		
		JLabel choose9 = new JLabel();
		choose9.setText("You Chose: "+nineN1 );
		choose9.setBounds(100, 500, 250, 250);
		choose9.setLayout(null);
		choose9.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose9.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(choose9);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 9          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 6" );
		nineNine.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == nine.nineC2 && nineN2==c9Name) {
		this.nine.setVisible(false);
		this.nineNine.setVisible(true);
		this.mainFrame.add(nineNine);
		
		JLabel choose9 = new JLabel();
		choose9.setText("You Chose: "+nineN2 );
		choose9.setBounds(100, 500, 250, 250);
		choose9.setLayout(null);
		choose9.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose9.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(choose9);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 9          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 6" );
		nineNine.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == nine.nineC3 && nineN3==c9Name) {
		this.nine.setVisible(false);
		this.nineNine.setVisible(true);
		this.mainFrame.add(nineNine);
		
		JLabel choose9 = new JLabel();
		choose9.setText("You Chose: "+nineN3 );
		choose9.setBounds(100, 500, 250, 250);
		choose9.setLayout(null);
		choose9.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose9.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(choose9);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 9          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 6" );
		nineNine.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == nine.nineC4 && nineN4==c9Name) {
		this.nine.setVisible(false);
		this.nineNine.setVisible(true);
		this.mainFrame.add(nineNine);
		
		JLabel choose9 = new JLabel();
		choose9.setText("You Chose: "+nineN4 );
		choose9.setBounds(100, 500, 250, 250);
		choose9.setLayout(null);
		choose9.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose9.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(choose9);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 9          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 6" );
		nineNine.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == nine.nineC1 && ! (nineN1==c9Name)) {
		this.nine.setVisible(false);
		this.nineNine.setVisible(true);
		this.mainFrame.add(nineNine);
		
		JLabel choose9 = new JLabel();
		choose9.setText("You Chose: "+nineN1 );
		choose9.setBounds(100, 500, 250, 250);
		choose9.setLayout(null);
		choose9.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose9.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(choose9);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 9          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 6" );
		nineNine.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == nine.nineC2 && ! (nineN2==c9Name)) {
		this.nine.setVisible(false);
		this.nineNine.setVisible(true);
		this.mainFrame.add(nineNine);
		
		JLabel choose9 = new JLabel();
		choose9.setText("You Chose: "+nineN2 );
		choose9.setBounds(100, 500, 250, 250);
		choose9.setLayout(null);
		choose9.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose9.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(choose9);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 9          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 6" );
		nineNine.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == nine.nineC3 && ! (nineN3==c9Name)) {
		this.nine.setVisible(false);
		this.nineNine.setVisible(true);
		this.mainFrame.add(nineNine);
		
		JLabel choose9 = new JLabel();
		choose9.setText("You Chose: "+nineN3 );
		choose9.setBounds(100, 500, 250, 250);
		choose9.setLayout(null);
		choose9.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose9.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(choose9);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 9          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 6" );
		nineNine.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == nine.nineC4 && ! (nineN4==c9Name)) {
		this.nine.setVisible(false);
		this.nineNine.setVisible(true);
		this.mainFrame.add(nineNine);
		
		JLabel choose9 = new JLabel();
		choose9.setText("You Chose: "+nineN4 );
		choose9.setBounds(100, 500, 250, 250);
		choose9.setLayout(null);
		choose9.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose9.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(choose9);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		nineNine.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 9          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 6" );
		nineNine.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	//8/1/2022
	if(e.getSource() == nineNine.nineNineCont) {
		this.nineNine.setVisible(false);
		this.ten.setVisible(true);
		this.mainFrame.add(ten);
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 9          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 6" );
		ten.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
		
	}
	
	//23/1/2022
	if(e.getSource() == ten.tenC1 && tenN1==c10Name) {
		this.ten.setVisible(false);
		this.tenTen.setVisible(true);
		this.mainFrame.add(tenTen);
		
		JLabel choose10 = new JLabel();
		choose10.setText("You Chose: "+tenN1 );
		choose10.setBounds(100, 500, 250, 250);
		choose10.setLayout(null);
		choose10.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose10.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(choose10);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 10          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 5" );
		tenTen.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == ten.tenC2 && tenN2==c10Name) {
		this.ten.setVisible(false);
		this.tenTen.setVisible(true);
		this.mainFrame.add(tenTen);
		
		JLabel choose10 = new JLabel();
		choose10.setText("You Chose: "+tenN2 );
		choose10.setBounds(100, 500, 250, 250);
		choose10.setLayout(null);
		choose10.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose10.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(choose10);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 10          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 5" );
		tenTen.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == ten.tenC3 && tenN3==c10Name) {
		this.ten.setVisible(false);
		this.tenTen.setVisible(true);
		this.mainFrame.add(tenTen);
		
		JLabel choose10 = new JLabel();
		choose10.setText("You Chose: "+tenN3 );
		choose10.setBounds(100, 500, 250, 250);
		choose10.setLayout(null);
		choose10.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose10.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(choose10);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 10          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 5" );
		tenTen.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == ten.tenC4 && tenN4==c10Name) {
		this.ten.setVisible(false);
		this.tenTen.setVisible(true);
		this.mainFrame.add(tenTen);
		
		JLabel choose10 = new JLabel();
		choose10.setText("You Chose: "+tenN4 );
		choose10.setBounds(100, 500, 250, 250);
		choose10.setLayout(null);
		choose10.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose10.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(choose10);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 10          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 5" );
		tenTen.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	// 21/1/2022
	if(e.getSource() == ten.tenC1 && ! (tenN1==c10Name)) {
		this.ten.setVisible(false);
		this.tenTen.setVisible(true);
		this.mainFrame.add(tenTen);
		
		JLabel choose10 = new JLabel();
		choose10.setText("You Chose: "+tenN1 );
		choose10.setBounds(100, 500, 250, 250);
		choose10.setLayout(null);
		choose10.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose10.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(choose10);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 10          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 5" );
		tenTen.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == ten.tenC2 && ! (tenN2==c10Name)) {
		this.ten.setVisible(false);
		this.tenTen.setVisible(true);
		this.mainFrame.add(tenTen);
		
		JLabel choose10 = new JLabel();
		choose10.setText("You Chose: "+tenN2 );
		choose10.setBounds(100, 500, 250, 250);
		choose10.setLayout(null);
		choose10.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose10.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(choose10);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 10          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 5" );
		tenTen.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == ten.tenC3 && ! (tenN3==c10Name)) {
		this.ten.setVisible(false);
		this.tenTen.setVisible(true);
		this.mainFrame.add(tenTen);
		
		JLabel choose10 = new JLabel();
		choose10.setText("You Chose: "+tenN3 );
		choose10.setBounds(100, 500, 250, 250);
		choose10.setLayout(null);
		choose10.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose10.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(choose10);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 10          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 5" );
		tenTen.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == ten.tenC4 && ! (tenN4==c10Name)) {
		this.ten.setVisible(false);
		this.tenTen.setVisible(true);
		this.mainFrame.add(tenTen);
		
		JLabel choose10 = new JLabel();
		choose10.setText("You Chose: "+tenN4 );
		choose10.setBounds(100, 500, 250, 250);
		choose10.setLayout(null);
		choose10.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose10.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(choose10);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		tenTen.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 10          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 5" );
		tenTen.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == tenTen.tenTenCont) {
		this.tenTen.setVisible(false);
		this.eleven.setVisible(true);
		this.mainFrame.add(eleven);
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 10          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 5" );
		eleven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
		
	}
	
	//scam
	if(e.getSource() == eleven.elevenC1 && elevenN1==c11Name) {
		this.eleven.setVisible(false);
		this.elevenEleven.setVisible(true);
		this.mainFrame.add(elevenEleven);
		
		JLabel choose11 = new JLabel();
		choose11.setText("You Chose: "+elevenN1 );
		choose11.setBounds(100, 500, 250, 250);
		choose11.setLayout(null);
		choose11.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose11.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(choose11);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 11          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 4" );
		elevenEleven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eleven.elevenC2 && elevenN2==c11Name) {
		this.eleven.setVisible(false);
		this.elevenEleven.setVisible(true);
		this.mainFrame.add(elevenEleven);
		
		JLabel choose11 = new JLabel();
		choose11.setText("You Chose: "+elevenN2 );
		choose11.setBounds(100, 500, 250, 250);
		choose11.setLayout(null);
		choose11.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose11.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(choose11);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 11          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 4" );
		elevenEleven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eleven.elevenC3 && elevenN3==c11Name) {
		this.eleven.setVisible(false);
		this.elevenEleven.setVisible(true);
		this.mainFrame.add(elevenEleven);
		
		JLabel choose11 = new JLabel();
		choose11.setText("You Chose: "+elevenN3 );
		choose11.setBounds(100, 500, 250, 250);
		choose11.setLayout(null);
		choose11.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose11.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(choose11);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 11          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 4" );
		elevenEleven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eleven.elevenC4 && elevenN4==c11Name) {
		this.eleven.setVisible(false);
		this.elevenEleven.setVisible(true);
		this.mainFrame.add(elevenEleven);
		
		JLabel choose11 = new JLabel();
		choose11.setText("You Chose: "+elevenN4 );
		choose11.setBounds(100, 500, 250, 250);
		choose11.setLayout(null);
		choose11.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose11.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(choose11);
		
		JLabel res;
		res = new JLabel();
		res.setText("Right Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(res);
		ra++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 11          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 4" );
		elevenEleven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	
	if(e.getSource() == eleven.elevenC1 && ! (elevenN1==c11Name)) {
		this.eleven.setVisible(false);
		this.elevenEleven.setVisible(true);
		this.mainFrame.add(elevenEleven);
		
		JLabel choose11 = new JLabel();
		choose11.setText("You Chose: "+elevenN1 );
		choose11.setBounds(100, 500, 250, 250);
		choose11.setLayout(null);
		choose11.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose11.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(choose11);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 11          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 4" );
		elevenEleven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eleven.elevenC2 && ! (elevenN2==c11Name)) {
		this.eleven.setVisible(false);
		this.elevenEleven.setVisible(true);
		this.mainFrame.add(elevenEleven);
		
		JLabel choose11 = new JLabel();
		choose11.setText("You Chose: "+elevenN2 );
		choose11.setBounds(100, 500, 250, 250);
		choose11.setLayout(null);
		choose11.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose11.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(choose11);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 11          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 4" );
		elevenEleven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eleven.elevenC3 && ! (elevenN3==c11Name)) {
		this.eleven.setVisible(false);
		this.elevenEleven.setVisible(true);
		this.mainFrame.add(elevenEleven);
		
		JLabel choose11 = new JLabel();
		choose11.setText("You Chose: "+elevenN3 );
		choose11.setBounds(100, 500, 250, 250);
		choose11.setLayout(null);
		choose11.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose11.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(choose11);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 11          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 4" );
		elevenEleven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	}
	
	if(e.getSource() == eleven.elevenC4 && ! (elevenN4==c11Name)) {
		this.eleven.setVisible(false);
		this.elevenEleven.setVisible(true);
		this.mainFrame.add(elevenEleven);
		
		JLabel choose11 = new JLabel();
		choose11.setText("You Chose: "+elevenN4 );
		choose11.setBounds(100, 500, 250, 250);
		choose11.setLayout(null);
		choose11.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		choose11.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(choose11);
		
		JLabel res;
		res = new JLabel();
		res.setText("Wrong Answer !!");
		res.setBounds(615, -35, 700, 600);
		res.setLayout(null);
		res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		res.setForeground(Color.decode("#5f2e1e"));
		elevenEleven.add(res);
		wa++;
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 11          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 4" );
		elevenEleven.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
	} 
	
	if(e.getSource() == elevenEleven.elevenElevenCont) {
		this.elevenEleven.setVisible(false);
		this.twelve.setVisible(true);
		this.mainFrame.add(twelve);
		
		JTextArea infoArea;
		infoArea = new JTextArea();
		infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		infoArea.setLayout(null);
		infoArea.setEditable(false);
		infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
		infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 11          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 4" );
		twelve.add(infoArea, BorderLayout.NORTH);
		infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
		infoArea.setBackground(Color.decode("#d0b27b"));
		infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
		infoArea.setForeground(Color.decode("#5f4021"));
		
	}
		
		//6/4/2022
		if(e.getSource() == twelve.twelveC1 && twelveN1==c12Name) {
			this.twelve.setVisible(false);
			this.twelveTwelve.setVisible(true);
			this.mainFrame.add(twelveTwelve);
			
			JLabel choose12 = new JLabel();
			choose12.setText("You Chose: "+twelveN1 );
			choose12.setBounds(100, 500, 250, 250);
			choose12.setLayout(null);
			choose12.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose12.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(choose12);
			
			JLabel res;
			res = new JLabel();
			res.setText("Right Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(res);
			ra++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 12          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 3" );
			twelveTwelve.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == twelve.twelveC2 && twelveN2==c12Name) {
			this.twelve.setVisible(false);
			this.twelveTwelve.setVisible(true);
			this.mainFrame.add(twelveTwelve);
			
			JLabel choose12 = new JLabel();
			choose12.setText("You Chose: "+twelveN2 );
			choose12.setBounds(100, 500, 250, 250);
			choose12.setLayout(null);
			choose12.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose12.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(choose12);
			
			JLabel res;
			res = new JLabel();
			res.setText("Right Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(res);
			ra++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 12          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 3" );
			twelveTwelve.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == twelve.twelveC3 && twelveN3==c12Name) {
			this.twelve.setVisible(false);
			this.twelveTwelve.setVisible(true);
			this.mainFrame.add(twelveTwelve);
			
			JLabel choose12 = new JLabel();
			choose12.setText("You Chose: "+twelveN3 );
			choose12.setBounds(100, 500, 250, 250);
			choose12.setLayout(null);
			choose12.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose12.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(choose12);
			
			JLabel res;
			res = new JLabel();
			res.setText("Right Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(res);
			ra++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 12          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 3" );
			twelveTwelve.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == twelve.twelveC4 && twelveN4==c12Name) {
			this.twelve.setVisible(false);
			this.twelveTwelve.setVisible(true);
			this.mainFrame.add(twelveTwelve);
			
			JLabel choose12 = new JLabel();
			choose12.setText("You Chose: "+twelveN4 );
			choose12.setBounds(100, 500, 250, 250);
			choose12.setLayout(null);
			choose12.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose12.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(choose12);
			
			JLabel res;
			res = new JLabel();
			res.setText("Right Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(res);
			ra++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 12          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 3" );
			twelveTwelve.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		
		if(e.getSource() == twelve.twelveC1 && ! (twelveN1==c12Name)) {
			this.twelve.setVisible(false);
			this.twelveTwelve.setVisible(true);
			this.mainFrame.add(twelveTwelve);
			
			JLabel choose12 = new JLabel();
			choose12.setText("You Chose: "+twelveN1 );
			choose12.setBounds(100, 500, 250, 250);
			choose12.setLayout(null);
			choose12.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose12.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(choose12);
			
			JLabel res;
			res = new JLabel();
			res.setText("Wrong Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(res);
			wa++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 12          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 3" );
			twelveTwelve.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == twelve.twelveC2 && ! (twelveN2==c12Name)) {
			this.twelve.setVisible(false);
			this.twelveTwelve.setVisible(true);
			this.mainFrame.add(twelveTwelve);
			
			JLabel choose12 = new JLabel();
			choose12.setText("You Chose: "+twelveN2 );
			choose12.setBounds(100, 500, 250, 250);
			choose12.setLayout(null);
			choose12.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose12.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(choose12);
			
			JLabel res;
			res = new JLabel();
			res.setText("Wrong Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(res);
			wa++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 12          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 3" );
			twelveTwelve.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == twelve.twelveC3 && ! (twelveN3==c12Name)) {
			this.twelve.setVisible(false);
			this.twelveTwelve.setVisible(true);
			this.mainFrame.add(twelveTwelve);
			
			JLabel choose12 = new JLabel();
			choose12.setText("You Chose: "+twelveN3 );
			choose12.setBounds(100, 500, 250, 250);
			choose12.setLayout(null);
			choose12.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose12.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(choose12);
			
			JLabel res;
			res = new JLabel();
			res.setText("Wrong Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(res);
			wa++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 12          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 3" );
			twelveTwelve.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == twelve.twelveC4 && ! (twelveN4==c12Name)) {
			this.twelve.setVisible(false);
			this.twelveTwelve.setVisible(true);
			this.mainFrame.add(twelveTwelve);
			
			JLabel choose12 = new JLabel();
			choose12.setText("You Chose: "+twelveN4 );
			choose12.setBounds(100, 500, 250, 250);
			choose12.setLayout(null);
			choose12.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose12.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(choose12);
			
			JLabel res;
			res = new JLabel();
			res.setText("Wrong Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			twelveTwelve.add(res);
			wa++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 12          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 3" );
			twelveTwelve.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == twelveTwelve.twelveTwelveCont) {
			this.twelveTwelve.setVisible(false);
			this.thirteen.setVisible(true);
			this.mainFrame.add(thirteen);
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 12          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 3" );
			thirteen.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
			
		}
		
		//taxation quiz
		if(e.getSource() == thirteen.thirteenC1 && thirteenN1==c13Name) {
			this.thirteen.setVisible(false);
			this.thirteenThirteen.setVisible(true);
			this.mainFrame.add(thirteenThirteen);
			
			JLabel choose13 = new JLabel();
			choose13.setText("You Chose: "+thirteenN1 );
			choose13.setBounds(100, 500, 250, 250);
			choose13.setLayout(null);
			choose13.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose13.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(choose13);
			
			JLabel res;
			res = new JLabel();
			res.setText("Right Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(res);
			ra++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 13          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 2" );
			thirteenThirteen.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == thirteen.thirteenC2 && thirteenN2==c13Name) {
			this.thirteen.setVisible(false);
			this.thirteenThirteen.setVisible(true);
			this.mainFrame.add(thirteenThirteen);
			
			JLabel choose13 = new JLabel();
			choose13.setText("You Chose: "+thirteenN2 );
			choose13.setBounds(100, 500, 250, 250);
			choose13.setLayout(null);
			choose13.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose13.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(choose13);
			
			JLabel res;
			res = new JLabel();
			res.setText("Right Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(res);
			ra++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 13          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 2" );
			thirteenThirteen.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == thirteen.thirteenC3 && thirteenN3==c13Name) {
			this.thirteen.setVisible(false);
			this.thirteenThirteen.setVisible(true);
			this.mainFrame.add(thirteenThirteen);
			
			JLabel choose13 = new JLabel();
			choose13.setText("You Chose: "+thirteenN3 );
			choose13.setBounds(100, 500, 250, 250);
			choose13.setLayout(null);
			choose13.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose13.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(choose13);
			
			JLabel res;
			res = new JLabel();
			res.setText("Right Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(res);
			ra++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 13          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 2" );
			thirteenThirteen.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == thirteen.thirteenC4 && thirteenN4==c13Name) {
			this.thirteen.setVisible(false);
			this.thirteenThirteen.setVisible(true);
			this.mainFrame.add(thirteenThirteen);
			
			JLabel choose13 = new JLabel();
			choose13.setText("You Chose: "+thirteenN1 );
			choose13.setBounds(100, 500, 250, 250);
			choose13.setLayout(null);
			choose13.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose13.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(choose13);
			
			JLabel res;
			res = new JLabel();
			res.setText("Right Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(res);
			ra++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 13          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 2" );
			thirteenThirteen.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		//watch
		if(e.getSource() == thirteen.thirteenC1 && ! (thirteenN1==c13Name)) {
			this.thirteen.setVisible(false);
			this.thirteenThirteen.setVisible(true);
			this.mainFrame.add(thirteenThirteen);
			
			JLabel choose13 = new JLabel();
			choose13.setText("You Chose: "+thirteenN1 );
			choose13.setBounds(100, 500, 250, 250);
			choose13.setLayout(null);
			choose13.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose13.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(choose13);
			
			JLabel res;
			res = new JLabel();
			res.setText("Wrong Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(res);
			wa++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 13          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 2" );
			thirteenThirteen.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == thirteen.thirteenC2 && ! (thirteenN2==c13Name)) {
			this.thirteen.setVisible(false);
			this.thirteenThirteen.setVisible(true);
			this.mainFrame.add(thirteenThirteen);
			
			JLabel choose13 = new JLabel();
			choose13.setText("You Chose: "+thirteenN2);
			choose13.setBounds(100, 500, 250, 250);
			choose13.setLayout(null);
			choose13.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose13.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(choose13);
			
			JLabel res;
			res = new JLabel();
			res.setText("Wrong Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(res);
			wa++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 13          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 2" );
			thirteenThirteen.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == thirteen.thirteenC3 && ! (thirteenN3==c13Name)) {
			this.thirteen.setVisible(false);
			this.thirteenThirteen.setVisible(true);
			this.mainFrame.add(thirteenThirteen);
			
			JLabel choose13 = new JLabel();
			choose13.setText("You Chose: "+thirteenN3 );
			choose13.setBounds(100, 500, 250, 250);
			choose13.setLayout(null);
			choose13.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose13.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(choose13);
			
			JLabel res;
			res = new JLabel();
			res.setText("Wrong Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(res);
			wa++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 13          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 2" );
			thirteenThirteen.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
		
		if(e.getSource() == thirteen.thirteenC4 && ! (thirteenN4==c13Name)) {
			this.thirteen.setVisible(false);
			this.thirteenThirteen.setVisible(true);
			this.mainFrame.add(thirteenThirteen);
			
			JLabel choose13 = new JLabel();
			choose13.setText("You Chose: "+thirteenN4);
			choose13.setBounds(100, 500, 250, 250);
			choose13.setLayout(null);
			choose13.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			choose13.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(choose13);
			
			JLabel res;
			res = new JLabel();
			res.setText("Wrong Answer !!");
			res.setBounds(615, -35, 700, 600);
			res.setLayout(null);
			res.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			res.setForeground(Color.decode("#5f2e1e"));
			thirteenThirteen.add(res);
			wa++;
			
			JTextArea infoArea;
			infoArea = new JTextArea();
			infoArea.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
			infoArea.setLayout(null);
			infoArea.setEditable(false);
			infoArea.setBounds(0, 0, this.mainFrame.getWidth(), 100);
			infoArea.setText("Name: "+this.chooseLevelFrame.userName.getText()+"          Level: "+ l + "          Flags Examined: 13          " + "Right Answers: "+ ra + "          Wrong Answers : "+ wa +"          Flags Remaining: 2" );
			thirteenThirteen.add(infoArea, BorderLayout.NORTH);
			infoArea.setBorder(BorderFactory.createLineBorder(Color.decode("#d0b27b"), 5));
			infoArea.setBackground(Color.decode("#d0b27b"));
			infoArea.setFont(new Font(Font.SERIF, Font.BOLD, 20));
			infoArea.setForeground(Color.decode("#5f4021"));
		}
	
}	

public static String[] names (String l) {

String [] temp = new String [31];
if (l == "Easy") {
	
String [] countryName = {"Algeria","Brazil","Canada","China","Denmark","Egypt","France","Germany","Italy","Japan", "Lebanon", "Libya", "New Zealand", "Qatar","Russia","Saudi Arabia","South Africa", "Spain","Tunisia","Turkey", "England", "USA","Yemen","Argentina","Belgium","Australia","Greece","Palestine","United Arab Emirates","Ireland","Morocco"};	
return countryName;

}

else if (l=="Medium") {
String [] countryName = {"Afghanistan","Angola","Cameroon","Croatia","Finland","India","Iran","Iraq","Mexico","Netherlands", "Nigeria", "Portugal", "Romania", "Senegal","South Korea","Sudan","Sweden", "Switzerland","Syria","Ukraine", "Uruguay", "Kuwait","Poland","Albania","Colombia","Bahrain","Hungary","Jordan","Norway","Ghana","Oman"};	
return countryName;

}

else if (l=="Hard") {
String [] countryName = {"Armenia","Austria","Bangladesh","Benin","Bolivia","Bosnia and Herzegovina","Bulgaria","Burkina Faso","Chile","Cote d'Ivoire", "Czech Republic", "Ecuador", "Ethiopia", "Gabon","Guinea","Iceland","Jamaica", "Kenya","Mali","Mozambique", "North Korea", "Panama","Paraguay","Serbia","Slovakia","Somalia","Thailand","Togo","Uganda","Venezuela","Vietnam"};	
return countryName;

}

//leveling
else if (l=="Very Hard") {
String [] countryName = {"Azerbaijan","Bahamas","Belarus","Burundi","Chad","Congo","Costa Rica","Cuba","Cyprus","Gambia", "Guyana", "Honduras", "Indonesia", "Kosovo","Liberia","Madagascar","Malaysia", "Maldives","Malta","Namibia", "Nepal", "Niger","Pakistan","Peru","Philippines","Rwanda","Singapore","Taiwan","Tanzania","Zambia","Zimbabwe"};	
return countryName;

}

return temp;
	
}

public static String capitals (String l,int x) {

String c = "Unknown";
if (l == "Easy") {
	
String [] countryName = {"Algiers","Brasilia","Ottawa","Beijing","Copenhagen","Cairo","Paris","Berlin","Roma","Tokyo", "Beirut", "Tripoli", "Wellington", "Doha","Moscow","Riyadh","Cape Town", "Madrid","Tunis","Ankara", "London", "Washington","Sana'a","Buenos Aires","Brussels","Canberra","Athens","Jerusalem","Abu Dhabi","Dublin","Rabat"};	
c=countryName[x];

}

else if (l=="Medium") {
String [] countryName = {"Kabul","Luanda","Yaound�","Zagreb","Helsinki","New Delhi","Tehran","Baghdad","Mexico City","Amsterdam", "Abuja", "Lisbon", "Bucharest", "Dakar","Seoul","Khartoum","Stockholm", "Bern","Damascus","Kyiv", "Montevideo", "Kuwait City","Warsaw","Tirana","Bogot�","Manama","Budapest","Amman","Oslo","Accra","Muscat"};	
c=countryName[x];

}

else if (l=="Hard") {
String [] countryName = {"Yerevan","Vienna","Dhaka","Porto-Novo","Sucre","Sarajevo","Sofia","Ouagadougou","Santiago","Yamoussoukro", "Prague", "Quito", "Addis Ababa", "Libreville","Conakry","Reykjav�k","Kingston", "Nairobi","Bamako","Maputo", "Pyongyang", "Panama City","Asunci�n","Belgrade","Bratislava","Mogadishu","Bangkok","Lom�","Kampala","Caracas","Hanoi"};	
c=countryName[x];

}

//leveling
else if (l=="Very Hard") {
String [] countryName = {"Baku","Nassau","Minsk","Gitega","N'Djamena","Kinshasa","San Jos�","Havana","Nicosia","Banjul", "Georgetown", "Tegucigalpa", "Jakarta", "Pristina","Monrovia","Antananarivo","Kuala Lumpur", "Mal�","Valletta","Windhoek", "Kathmandu", "Niamey","Islamabad","Lima","Manila","Kigali","Singapore","Taipei City","Dodoma","Lusaka","Harare"};	
c=countryName[x];

}

return c;
	
}

public static void main (String [] args) {
	
control c = new control();
	
}
}
