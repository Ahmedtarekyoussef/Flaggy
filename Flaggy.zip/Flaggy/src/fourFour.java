import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class fourFour extends JPanel {
	
JButton fourFourCont;	
JButton fourFourRestart;

public fourFour() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.fourFourCont= new JButton();
	this.fourFourCont.setLayout(null);
	this.fourFourCont.setBounds(900, 550, 300, 50);
	this.fourFourCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.fourFourCont.setForeground(Color.decode("#540a04"));
	this.fourFourCont.setBackground(Color.decode("#d3842e"));
	this.fourFourCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.fourFourCont.setText("Go To Flag 5");
	this.add(fourFourCont);
	
	this.fourFourRestart= new JButton();
	this.fourFourRestart.setLayout(null);
	this.fourFourRestart.setBounds(1200, 5, 160, 40);
	this.fourFourRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.fourFourRestart.setForeground(Color.decode("#162550"));
	this.fourFourRestart.setBackground(Color.decode("#d3842e"));
	this.fourFourRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.fourFourRestart.setText("Restart Game");
	this.add(fourFourRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
}
	
}
