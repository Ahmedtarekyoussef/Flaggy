import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class eight extends JPanel {
	
JButton eightRestart;
JButton eightC1;
JButton eightC2;
JButton eightC3;
JButton eightC4;
JLabel eightL;

public eight() {
	
	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	eightC1= new JButton();
	eightC1.setLayout(null);
	eightC1.setBounds(375, 400, 400, 50);
	eightC1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	eightC1.setForeground(Color.decode("#162550"));
	eightC1.setBackground(Color.decode("#d3842e"));
	eightC1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	eightC1.setText("");
	this.add(eightC1);
	
	eightC2= new JButton();
	eightC2.setLayout(null);
	eightC2.setBounds(900, 400, 300, 50);
	eightC2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	eightC2.setForeground(Color.decode("#162550"));
	eightC2.setBackground(Color.decode("#d3842e"));
	eightC2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	eightC2.setText("");
	this.add(eightC2);
	
	eightC3= new JButton();
	eightC3.setLayout(null);
	eightC3.setBounds(375, 550, 300, 50);
	eightC3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	eightC3.setForeground(Color.decode("#162550"));
	eightC3.setBackground(Color.decode("#d3842e"));
	eightC3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	eightC3.setText("");
	this.add(eightC3);
	
	eightC4= new JButton();
	eightC4.setLayout(null);
	eightC4.setBounds(900, 550, 300, 50);
	eightC4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	eightC4.setForeground(Color.decode("#162550"));
	eightC4.setBackground(Color.decode("#d3842e"));
	eightC4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	eightC4.setText("");
	this.add(eightC4);
	
	this.eightRestart= new JButton();
	this.eightRestart.setLayout(null);
	this.eightRestart.setBounds(1200, 5, 160, 40);
	this.eightRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.eightRestart.setForeground(Color.decode("#162550"));
	this.eightRestart.setBackground(Color.decode("#d3842e"));
	this.eightRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.eightRestart.setText("Restart Game");
	this.add(eightRestart);
	
	JLabel eightL = new JLabel();
	eightL.setText("Flag 8" );
	eightL.setBounds(1200, 50, 160, 40);
	eightL.setLayout(null);
	eightL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	eightL.setForeground(Color.decode("#5f2e1e"));
	this.add(eightL);

}
}
