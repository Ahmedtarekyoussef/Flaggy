import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class six extends JPanel {
	
JButton sixRestart;
JButton sixC1;
JButton sixC2;
JButton sixC3;
JButton sixC4;	
JLabel sixL;

public six() {
	
	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	sixC1= new JButton();
	sixC1.setLayout(null);
	sixC1.setBounds(375, 400, 400, 50);
	sixC1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	sixC1.setForeground(Color.decode("#162550"));
	sixC1.setBackground(Color.decode("#d3842e"));
	sixC1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	sixC1.setText("");
	this.add(sixC1);
	
	sixC2= new JButton();
	sixC2.setLayout(null);
	sixC2.setBounds(900, 400, 300, 50);
	sixC2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	sixC2.setForeground(Color.decode("#162550"));
	sixC2.setBackground(Color.decode("#d3842e"));
	sixC2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	sixC2.setText("");
	this.add(sixC2);
	
	sixC3= new JButton();
	sixC3.setLayout(null);
	sixC3.setBounds(375, 550, 300, 50);
	sixC3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	sixC3.setForeground(Color.decode("#162550"));
	sixC3.setBackground(Color.decode("#d3842e"));
	sixC3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	sixC3.setText("");
	this.add(sixC3);
	
	sixC4= new JButton();
	sixC4.setLayout(null);
	sixC4.setBounds(900, 550, 300, 50);
	sixC4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	sixC4.setForeground(Color.decode("#162550"));
	sixC4.setBackground(Color.decode("#d3842e"));
	sixC4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	sixC4.setText("");
	this.add(sixC4);
	
	this.sixRestart= new JButton();
	this.sixRestart.setLayout(null);
	this.sixRestart.setBounds(1200, 5, 160, 40);
	this.sixRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.sixRestart.setForeground(Color.decode("#162550"));
	this.sixRestart.setBackground(Color.decode("#d3842e"));
	this.sixRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.sixRestart.setText("Restart Game");
	this.add(sixRestart);
	
	JLabel sixL = new JLabel();
	sixL.setText("Flag 6" );
	sixL.setBounds(1200, 50, 160, 40);
	sixL.setLayout(null);
	sixL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	sixL.setForeground(Color.decode("#5f2e1e"));
	this.add(sixL);

}
}
