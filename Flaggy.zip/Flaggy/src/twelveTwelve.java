import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class twelveTwelve extends JPanel {
	
JButton twelveTwelveCont;	
JButton twelveTwelveRestart;

public twelveTwelve() {

	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	this.twelveTwelveCont= new JButton();
	this.twelveTwelveCont.setLayout(null);
	this.twelveTwelveCont.setBounds(900, 550, 300, 50);
	this.twelveTwelveCont.setFont(new Font(Font.SERIF, Font.BOLD, 20));   
	this.twelveTwelveCont.setForeground(Color.decode("#540a04"));
	this.twelveTwelveCont.setBackground(Color.decode("#d3842e"));
	this.twelveTwelveCont.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.twelveTwelveCont.setText("Go To Flag 13");
	this.add(twelveTwelveCont);
	
	this.twelveTwelveRestart= new JButton();
	this.twelveTwelveRestart.setLayout(null);
	this.twelveTwelveRestart.setBounds(1200, 5, 160, 40);
	this.twelveTwelveRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.twelveTwelveRestart.setForeground(Color.decode("#162550"));
	this.twelveTwelveRestart.setBackground(Color.decode("#d3842e"));
	this.twelveTwelveRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.twelveTwelveRestart.setText("Restart Game");
	this.add(twelveTwelveRestart);
	
	JLabel flag = new JLabel();
	flag.setText("Flag:");
	flag.setBounds(10, 255, 100, 70);
	flag.setLayout(null);
	flag.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	flag.setForeground(Color.decode("#5f2e1e"));
	this.add(flag);
	
}
	
}
