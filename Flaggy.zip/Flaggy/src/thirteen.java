import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class thirteen extends JPanel {
	
JButton thirteenRestart;
JButton thirteenC1;
JButton thirteenC2;
JButton thirteenC3;
JButton thirteenC4;	
JLabel thirteenL;

public thirteen() {
	
	this.setLayout(null);
	this.setPreferredSize(new Dimension(1920,1080));
	this.setBackground(Color.decode("#e6c580"));
	
	thirteenC1= new JButton();
	thirteenC1.setLayout(null);
	thirteenC1.setBounds(375, 400, 400, 50);
	thirteenC1.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	thirteenC1.setForeground(Color.decode("#162550"));
	thirteenC1.setBackground(Color.decode("#d3842e"));
	thirteenC1.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	thirteenC1.setText("");
	this.add(thirteenC1);
	
	thirteenC2= new JButton();
	thirteenC2.setLayout(null);
	thirteenC2.setBounds(900, 400, 300, 50);
	thirteenC2.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	thirteenC2.setForeground(Color.decode("#162550"));
	thirteenC2.setBackground(Color.decode("#d3842e"));
	thirteenC2.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	thirteenC2.setText("");
	this.add(thirteenC2);
	
	thirteenC3= new JButton();
	thirteenC3.setLayout(null);
	thirteenC3.setBounds(375, 550, 300, 50);
	thirteenC3.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	thirteenC3.setForeground(Color.decode("#162550"));
	thirteenC3.setBackground(Color.decode("#d3842e"));
	thirteenC3.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	thirteenC3.setText("");
	this.add(thirteenC3);
	
	thirteenC4= new JButton();
	thirteenC4.setLayout(null);
	thirteenC4.setBounds(900, 550, 300, 50);
	thirteenC4.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	thirteenC4.setForeground(Color.decode("#162550"));
	thirteenC4.setBackground(Color.decode("#d3842e"));
	thirteenC4.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	thirteenC4.setText("");
	this.add(thirteenC4);
	
	this.thirteenRestart= new JButton();
	this.thirteenRestart.setLayout(null);
	this.thirteenRestart.setBounds(1200, 5, 160, 40);
	this.thirteenRestart.setFont(new Font(Font.SERIF, Font.BOLD, 20));
	this.thirteenRestart.setForeground(Color.decode("#162550"));
	this.thirteenRestart.setBackground(Color.decode("#d3842e"));
	this.thirteenRestart.setBorder(BorderFactory.createLineBorder(Color.decode("#d3842e"), 5));
	this.thirteenRestart.setText("Restart Game");
	this.add(thirteenRestart);
	
	JLabel thirteenL = new JLabel();
	thirteenL.setText("Flag 13" );
	thirteenL.setBounds(1200, 50, 160, 40);
	thirteenL.setLayout(null);
	thirteenL.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
	thirteenL.setForeground(Color.decode("#5f2e1e"));
	this.add(thirteenL);

}
}
